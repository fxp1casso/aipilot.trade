import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { cn } from "@/lib/utils"
import { FloatingNav } from "@/components/floating-nav"
import { FloatingCommunityHub } from "@/components/floating-community-hub"

const fontSans = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
  preload: true,
})

export const metadata: Metadata = {
  title: "ArchioAI Trading Terminal",
  description: "Professional-grade AI-powered trading terminal",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
      </head>
      <body className={cn("min-h-screen bg-background font-sans antialiased", fontSans.variable)}>
        {children}
        {/* Global floating menu visible on every page */}
        <FloatingNav />
        {/* Global community hub: floating icon with Chat and Forecast Room */}
        <FloatingCommunityHub />
      </body>
    </html>
  )
}
