import type React from "react"
import { Toaster } from "@/components/ui/toaster"

export default function MainLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Remove global Header/FloatingNav and the main wrapper.
  // This lets each page own its full-bleed background (e.g., the glow/glass effects).
  return (
    <div className="min-h-screen">
      {children}
      <Toaster />
    </div>
  )
}
