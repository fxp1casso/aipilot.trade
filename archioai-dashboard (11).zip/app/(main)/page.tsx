"use client"

import { LiveMarketIntelligence } from "@/components/live-market-intelligence"

export default function DashboardPage() {
  return <LiveMarketIntelligence />
}
