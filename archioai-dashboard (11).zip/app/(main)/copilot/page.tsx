import { ExecutionCopilotLayout } from "@/components/execution-copilot/execution-copilot-layout"

export default function CopilotPage() {
  return <ExecutionCopilotLayout />
}
