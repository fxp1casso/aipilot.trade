"use client"
import { NexusMindmap } from "@/components/nexus/nexus-mindmap"
import { NexusControlPanel } from "@/components/nexus/nexus-control-panel"
import { NexusAISynthesisPanel } from "@/components/nexus/nexus-ai-synthesis-panel"
import { NexusNodeDetailPanel } from "@/components/nexus/nexus-node-detail-panel"
import { useNexusGraph } from "@/hooks/use-nexus-graph"

export default function NexusPage() {
  const {
    nodes,
    edges,
    layouts,
    activeLayout,
    setActiveLayout,
    handleNodeClick,
    handlePaneClick,
    selectedNode,
    setSelectedNode,
  } = useNexusGraph()

  return (
    <div className="h-screen w-full bg-slate-950 text-white relative flex overflow-hidden">
      <div className="flex-grow relative">
        <NexusMindmap
          nodes={nodes}
          edges={edges}
          layouts={layouts}
          activeLayout={activeLayout}
          onNodeClick={handleNodeClick}
          onPaneClick={handlePaneClick}
        />
        <NexusControlPanel
          layouts={Object.keys(layouts)}
          activeLayout={activeLayout}
          onLayoutChange={setActiveLayout}
        />
        <NexusAISynthesisPanel />
      </div>
      <NexusNodeDetailPanel node={selectedNode} onClose={() => setSelectedNode(null)} />
    </div>
  )
}
