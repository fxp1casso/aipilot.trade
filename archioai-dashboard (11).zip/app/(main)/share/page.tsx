import { ForecastShareCard } from "@/components/forecast-share-card"

export default function SharePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-zinc-900 to-slate-900">
      <div className="container mx-auto py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Forecast Share Designer</h1>
          <p className="text-zinc-400">Create professional forecast cards with all confluences and psychology data</p>
        </div>
        <ForecastShareCard />
      </div>
    </div>
  )
}
