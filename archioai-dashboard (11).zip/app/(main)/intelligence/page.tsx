import { MrktIntelligenceDashboard } from "@/components/mrkt-intelligence-dashboard"

export default function IntelligencePage() {
  return <MrktIntelligenceDashboard />
}
