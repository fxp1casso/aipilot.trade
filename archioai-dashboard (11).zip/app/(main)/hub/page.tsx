"use client"

import { StudentCollaborationHub } from "@/components/student-collaboration-hub"

export default function HubPage() {
  return <StudentCollaborationHub />
}
