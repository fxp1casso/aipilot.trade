"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetTrigger, SheetContent } from "@/components/ui/sheet"
import { Menu, Brain, Bell } from "lucide-react"
import { usePathname } from "next/navigation"

const navItems = [
  { name: "Dashboard", link: "/" },
  { name: "AI Forecasts", link: "/intelligence" },
  { name: "Student Hub", link: "/hub" },
  { name: "Execution Co-Pilot", link: "/copilot" },
  { name: "Nexus", link: "/nexus" },
]

export function Header() {
  const pathname = usePathname()

  return (
    <header className="bg-matte-black/80 backdrop-blur-lg sticky top-0 z-50 border-b border-slate-grey">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-2">
              <Brain className="w-8 h-8 text-luxury-gold" />
              <span className="text-xl font-bold uppercase tracking-widest text-white">ARCHIO AI</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-white hover:bg-slate-grey">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <Button className="bg-luxury-gold text-matte-black hover:bg-amber-300 font-bold">Login</Button>
          </div>

          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6 text-white" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-matte-black border-slate-grey text-white w-[250px] sm:w-[300px]">
                <div className="flex flex-col gap-4 p-4">
                  <Button className="bg-luxury-gold text-matte-black hover:bg-amber-300 font-bold w-full mt-4">
                    Login
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
