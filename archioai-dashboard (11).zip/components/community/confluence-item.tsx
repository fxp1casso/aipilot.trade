"use client"

import { motion } from "framer-motion"

const barColor = (score: number) => {
  if (score >= 80) return "bg-green-500"
  if (score >= 60) return "bg-yellow-500"
  return "bg-red-500"
}

export function ConfluenceItem({ name, score, delay }: { name: string; score: number; delay: number }) {
  return (
    <motion.div
      className="flex items-center justify-between text-sm"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <span className="text-zinc-300">{name}</span>
      <div className="flex items-center gap-2">
        <div className="w-24 h-1.5 bg-zinc-700 rounded-full overflow-hidden">
          <motion.div
            className={`h-full ${barColor(score)}`}
            initial={{ width: 0 }}
            animate={{ width: `${score}%` }}
            transition={{ duration: 0.8, delay: delay + 0.2, ease: "easeOut" }}
          />
        </div>
        <span className="w-8 text-right font-mono text-zinc-400">{score}%</span>
      </div>
    </motion.div>
  )
}
