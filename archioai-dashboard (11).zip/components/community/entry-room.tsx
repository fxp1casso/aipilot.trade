"use client"

import { motion } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { MessageSquare, ThumbsUp, Search } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { mockEntries } from "@/lib/community-data"
import { ConfluenceTag } from "./confluence-tag"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 12,
    },
  },
}

export function EntryRoom() {
  return (
    <ScrollArea className="h-full">
      <motion.div variants={containerVariants} initial="hidden" animate="visible" className="p-4 space-y-4">
        {mockEntries.map((entry) => (
          <motion.div
            key={entry.id}
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="bg-slate-grey/50 p-4 rounded-xl border border-zinc-800 hover:border-cyan-400/30 transition-colors shadow-lg shadow-black/20"
          >
            <div className="flex items-start gap-3">
              <Avatar className="w-10 h-10 border-2 border-zinc-700">
                <AvatarImage src={entry.user.avatar || "/placeholder.svg"} />
                <AvatarFallback>{entry.user.name.slice(0, 1)}</AvatarFallback>
              </Avatar>
              <div className="flex-grow">
                <div className="flex justify-between items-center">
                  <p className="font-semibold text-zinc-100">{entry.user.name}</p>
                  <p className="text-xs text-zinc-500">{entry.timestamp}</p>
                </div>
                <p className="text-sm text-zinc-400">
                  Entered{" "}
                  <span className="font-bold text-cyan-400">
                    {entry.trade.pair} {entry.trade.direction}
                  </span>{" "}
                  @ {entry.trade.entryPrice}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 my-3">
              {entry.confluences.map((confluence, index) => (
                <ConfluenceTag key={confluence} delay={index * 0.05}>
                  {confluence}
                </ConfluenceTag>
              ))}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white h-auto px-2 py-1">
                  <ThumbsUp className="w-4 h-4 mr-2" />
                  {entry.social.likes}
                </Button>
                <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white h-auto px-2 py-1">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  {entry.social.comments}
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="bg-transparent border-cyan-400/50 text-cyan-400 hover:bg-cyan-400/10 hover:text-cyan-400 h-auto px-3 py-1.5"
              >
                <Search className="w-4 h-4 mr-2" />
                Review Entry
              </Button>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </ScrollArea>
  )
}
