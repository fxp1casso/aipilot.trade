"use client"

import type React from "react"

import { motion } from "framer-motion"

const tagVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0 },
}

export function ConfluenceTag({
  children,
  delay = 0,
}: {
  children: React.ReactNode
  delay?: number
}) {
  return (
    <motion.div
      variants={tagVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.3, delay }}
      className="text-xs bg-luxury-gold/10 text-luxury-gold px-2 py-1 rounded-md border border-luxury-gold/20"
    >
      {children}
    </motion.div>
  )
}
