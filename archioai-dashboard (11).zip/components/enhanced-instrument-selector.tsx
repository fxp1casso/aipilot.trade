"use client"

import { useState, useEffect, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Search,
  TrendingUp,
  TrendingDown,
  Activity,
  Globe,
  Zap,
  BarChart3,
  DollarSign,
  Bitcoin,
  Coins,
  X,
  Heart,
  Clock,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { Instrument } from "@/lib/instruments"

interface EnhancedInstrumentSelectorProps {
  instruments: Instrument[]
  onSelect: (instrument: Instrument) => void
  onClose?: () => void
  label: string
  category: "forex" | "indices" | "crypto" | "commodities"
  isOpen?: boolean
  favorites?: Instrument[]
  onFavoritesUpdate?: (favorites: Instrument[]) => void
  position?: { top: number; left: number }
}

// Mock real-time data - in production this would come from a WebSocket or API
const generateMockPriceData = (symbol: string) => {
  const basePrice = Math.random() * 100 + 1
  const change = (Math.random() - 0.5) * 10
  const changePercent = (change / basePrice) * 100
  const volume = Math.floor(Math.random() * 1000000) + 100000
  const volatility = Math.random() * 5 + 0.5

  return {
    price: basePrice.toFixed(symbol.includes("JPY") ? 3 : 5),
    change: change.toFixed(5),
    changePercent: changePercent.toFixed(2),
    volume: volume.toLocaleString(),
    volatility: volatility.toFixed(1),
    isPositive: change >= 0,
    marketStatus: Math.random() > 0.3 ? "open" : "closed",
    spread: (Math.random() * 0.01).toFixed(5),
  }
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "forex":
      return Globe
    case "indices":
      return BarChart3
    case "crypto":
      return Bitcoin
    case "commodities":
      return Coins
    default:
      return DollarSign
  }
}

const getCategoryColor = (category: string) => {
  switch (category) {
    case "forex":
      return "from-blue-500/20 to-cyan-500/20 border-blue-400/30"
    case "indices":
      return "from-purple-500/20 to-pink-500/20 border-purple-400/30"
    case "crypto":
      return "from-orange-500/20 to-yellow-500/20 border-orange-400/30"
    case "commodities":
      return "from-green-500/20 to-emerald-500/20 border-green-400/30"
    default:
      return "from-gray-500/20 to-slate-500/20 border-gray-400/30"
  }
}

export function EnhancedInstrumentSelector({
  instruments,
  onSelect,
  onClose,
  label,
  category,
  isOpen = false,
  favorites = [],
  onFavoritesUpdate,
  position,
}: EnhancedInstrumentSelectorProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const favoriteSymbols = favorites.map((f) => f.symbol)
  const [sortBy, setSortBy] = useState<"name" | "change" | "volume" | "volatility">("name")
  const [filterBy, setFilterBy] = useState<"all" | "favorites" | "trending">("all")
  const [priceData, setPriceData] = useState<Record<string, any>>({})

  // Generate mock price data for all instruments
  useEffect(() => {
    const data: Record<string, any> = {}
    instruments.forEach((instrument) => {
      data[instrument.symbol] = generateMockPriceData(instrument.symbol)
    })
    setPriceData(data)

    // Update prices every 2 seconds
    const interval = setInterval(() => {
      const updatedData: Record<string, any> = {}
      instruments.forEach((instrument) => {
        updatedData[instrument.symbol] = generateMockPriceData(instrument.symbol)
      })
      setPriceData(updatedData)
    }, 2000)

    return () => clearInterval(interval)
  }, [instruments])

  const toggleFavorite = (instrument: Instrument) => {
    if (!onFavoritesUpdate) return

    const isFavorite = favoriteSymbols.includes(instrument.symbol)
    let newFavorites: Instrument[]

    if (isFavorite) {
      newFavorites = favorites.filter((f) => f.symbol !== instrument.symbol)
    } else {
      newFavorites = [...favorites, instrument]
    }

    onFavoritesUpdate(newFavorites)
  }

  const filteredAndSortedInstruments = useMemo(() => {
    let filtered = instruments.filter(
      (instrument) =>
        instrument.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        instrument.symbol.toLowerCase().includes(searchQuery.toLowerCase()),
    )

    // Apply filters
    if (filterBy === "favorites") {
      filtered = filtered.filter((instrument) => favoriteSymbols.includes(instrument.symbol))
    } else if (filterBy === "trending") {
      filtered = filtered.filter((instrument) => {
        const data = priceData[instrument.symbol]
        return data && Math.abs(Number.parseFloat(data.changePercent)) > 1
      })
    }

    // Apply sorting
    filtered.sort((a, b) => {
      const aData = priceData[a.symbol]
      const bData = priceData[b.symbol]

      switch (sortBy) {
        case "change":
          return Number.parseFloat(bData?.changePercent || "0") - Number.parseFloat(aData?.changePercent || "0")
        case "volume":
          return (
            Number.parseInt(bData?.volume?.replace(/,/g, "") || "0") -
            Number.parseInt(aData?.volume?.replace(/,/g, "") || "0")
          )
        case "volatility":
          return Number.parseFloat(bData?.volatility || "0") - Number.parseFloat(aData?.volatility || "0")
        default:
          return a.name.localeCompare(b.name)
      }
    })

    return filtered
  }, [instruments, searchQuery, filterBy, sortBy, favoriteSymbols, priceData])

  const CategoryIcon = getCategoryIcon(category)

  if (!isOpen) return null

  return (
    <AnimatePresence>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
        onClick={onClose}
      />

      {/* Enhanced Modal */}
      <motion.div
        initial={{ opacity: 0, y: 10, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 10, scale: 0.95 }}
        transition={{ duration: 0.2 }}
        className="fixed z-50 w-[480px]"
        style={
          position
            ? {
                top: position.top + 8, // 8px below the button
                left: Math.max(16, Math.min(position.left, window.innerWidth - 480 - 16)), // Keep within viewport
              }
            : {
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
              }
        }
      >
        <div className="premium-glass-modal border border-white/10 backdrop-blur-2xl">
          {/* Header */}
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <CategoryIcon className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg font-semibold text-white">{label}</h3>
                <Badge className="bg-purple-500/20 text-purple-200 border-purple-400/30">
                  {filteredAndSortedInstruments.length}
                </Badge>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="premium-glass-icon-button">
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search instruments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 premium-glass-input"
              />
            </div>

            {/* Filters and Sort */}
            <div className="flex items-center justify-between mt-3 gap-2">
              <div className="flex items-center gap-2">
                <Button
                  variant={filterBy === "all" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setFilterBy("all")}
                  className="premium-glass-button text-xs"
                >
                  All
                </Button>
                <Button
                  variant={filterBy === "favorites" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setFilterBy("favorites")}
                  className="premium-glass-button text-xs"
                >
                  <Heart className="w-3 h-3 mr-1" />
                  Favorites
                </Button>
                <Button
                  variant={filterBy === "trending" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setFilterBy("trending")}
                  className="premium-glass-button text-xs"
                >
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Trending
                </Button>
              </div>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="premium-glass-input text-xs py-1 px-2 h-8"
              >
                <option value="name">Name</option>
                <option value="change">Change %</option>
                <option value="volume">Volume</option>
                <option value="volatility">Volatility</option>
              </select>
            </div>
          </div>

          {/* Instruments List */}
          <div className="max-h-96 overflow-y-auto">
            <div className="p-2 space-y-1">
              {filteredAndSortedInstruments.map((instrument) => {
                const data = priceData[instrument.symbol]
                const isFavorite = favoriteSymbols.includes(instrument.symbol)

                return (
                  <motion.button
                    key={instrument.id}
                    onClick={() => {
                      onSelect(instrument)
                      onClose?.()
                    }}
                    className="w-full p-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-400/30 transition-all duration-200 group"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {/* Instrument Icon */}
                        <div
                          className={`w-10 h-10 rounded-full bg-gradient-to-br ${getCategoryColor(category)} flex items-center justify-center`}
                        >
                          <span className="text-xs font-bold text-white">{instrument.symbol.substring(0, 2)}</span>
                        </div>

                        {/* Instrument Info */}
                        <div className="text-left">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-white">{instrument.symbol}</span>
                            {data?.marketStatus === "open" && (
                              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                            )}
                            {data?.marketStatus === "closed" && <div className="w-2 h-2 rounded-full bg-gray-400" />}
                          </div>
                          <div className="text-xs text-gray-400 truncate max-w-[200px]">{instrument.name}</div>
                        </div>
                      </div>

                      {/* Price Data */}
                      <div className="text-right flex items-center gap-3">
                        {data && (
                          <div className="space-y-1">
                            <div className="text-sm font-mono text-white">{data.price}</div>
                            <div
                              className={`text-xs font-medium flex items-center gap-1 ${
                                data.isPositive ? "text-green-400" : "text-red-400"
                              }`}
                            >
                              {data.isPositive ? (
                                <TrendingUp className="w-3 h-3" />
                              ) : (
                                <TrendingDown className="w-3 h-3" />
                              )}
                              {data.changePercent}%
                            </div>
                          </div>
                        )}

                        {/* Favorite Button */}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleFavorite(instrument)
                          }}
                          className="w-8 h-8 premium-glass-icon-button"
                        >
                          <Heart className={`w-4 h-4 ${isFavorite ? "fill-red-400 text-red-400" : "text-gray-400"}`} />
                        </Button>
                      </div>
                    </div>

                    {/* Additional Data Row */}
                    {data && (
                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                        <div className="flex items-center gap-4 text-xs text-gray-400">
                          <div className="flex items-center gap-1">
                            <Activity className="w-3 h-3" />
                            <span>Vol: {data.volume}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            <span>Volatility: {data.volatility}%</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <BarChart3 className="w-3 h-3" />
                            <span>Spread: {data.spread}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Clock className="w-3 h-3" />
                          <span>Live</span>
                        </div>
                      </div>
                    )}
                  </motion.button>
                )
              })}
            </div>
          </div>

          {/* Footer */}
          <div className="p-3 border-t border-white/10 bg-white/5">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>Real-time institutional data</span>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span>Live Market Data</span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}
