"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

const messages = [
  {
    user: "Alex",
    avatar: "/images/student1.png",
    text: "Watching that BPR on GBP/USD closely. Looks like a prime spot for institutional shorts.",
    color: "text-luxury-gold",
  },
  {
    user: "Emma",
    avatar: "/images/student2.png",
    text: "Agreed. DXY is showing strength, adds to the confluence.",
    color: "text-metallic-bronze",
  },
  {
    user: "James",
    avatar: "/placeholder.svg?height=40&width=40",
    text: "I'm waiting for a liquidity sweep above 1.3500 before considering an entry.",
    color: "text-muted-emerald",
  },
  {
    user: "You",
    avatar: "/placeholder.svg?height=40&width=40",
    text: "What's the sentiment on EUR/USD?",
    color: "text-cyan-400",
    isCurrentUser: true,
  },
  {
    user: "Sophia",
    avatar: "/placeholder.svg?height=40&width=40",
    text: "EUR/USD is choppy. I'm staying out until after the Fed speech.",
    color: "text-luxury-gold",
  },
]

export function CommunityChat() {
  return (
    <div className="bg-transparent h-full flex flex-col">
      <ScrollArea className="flex-grow p-4">
        <div className="space-y-4">
          {messages.map((msg, index) => (
            <div key={index} className={`flex items-start gap-3 ${msg.isCurrentUser ? "justify-end" : ""}`}>
              {!msg.isCurrentUser && (
                <Avatar className="w-8 h-8 border-2 border-zinc-700">
                  <AvatarImage src={msg.avatar || "/placeholder.svg"} />
                  <AvatarFallback>{msg.user.slice(0, 1)}</AvatarFallback>
                </Avatar>
              )}
              <div
                className={`p-3 rounded-lg max-w-[80%] ${msg.isCurrentUser ? "bg-luxury-gold/10 rounded-br-none" : "bg-slate-grey rounded-bl-none"}`}
              >
                {!msg.isCurrentUser && <p className={`text-xs font-bold mb-1 ${msg.color}`}>{msg.user}</p>}
                <p className="text-sm text-zinc-300">{msg.text}</p>
              </div>
              {msg.isCurrentUser && (
                <Avatar className="w-8 h-8 border-2 border-luxury-gold/50">
                  <AvatarImage src={msg.avatar || "/placeholder.svg"} />
                  <AvatarFallback>Y</AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
      <div className="p-4 border-t border-zinc-800 mt-auto bg-slate-grey/50">
        <div className="flex items-center gap-2">
          <Input
            placeholder="Type a message..."
            className="bg-zinc-800/50 border-zinc-700 focus:border-luxury-gold text-white h-9 text-sm"
          />
          <Button size="icon" className="bg-luxury-gold hover:bg-amber-300 text-matte-black flex-shrink-0 h-9 w-9">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
