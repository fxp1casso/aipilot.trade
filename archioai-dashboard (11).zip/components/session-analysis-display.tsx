"use client"

import { motion } from "framer-motion"
import { Clock, TrendingUp, TrendingDown, Activity } from "lucide-react"
import { XAxis, YAxis, ResponsiveContainer, ReferenceLine, Area, AreaChart } from "recharts"
import { useEffect, useState } from "react"
import type { SessionAnalysis, SessionData } from "@/lib/session-analysis"

interface SessionAnalysisDisplayProps {
  analysis: SessionAnalysis | null
  isLoading: boolean
}

function getCurrentSession() {
  const now = new Date()
  const hour = now.getHours()

  // Convert to UTC and then to different timezone hours for session detection
  // Asia: 8pm - 12am (20:00 - 00:00)
  // London: 2am - 8am (02:00 - 08:00)
  // New York: 8am - 5pm (08:00 - 17:00)

  if (hour >= 20 || hour < 0) return "Asia Session"
  if (hour >= 2 && hour < 8) return "London Session"
  if (hour >= 8 && hour < 17) return "New York Session"
  return null
}

function getIncomingSessions(currentActiveSession: string | null) {
  if (!currentActiveSession) return []

  switch (currentActiveSession) {
    case "Asia Session":
      return ["London Session", "New York Session"]
    case "London Session":
      return ["New York Session"]
    case "New York Session":
      return ["Asia Session"]
    default:
      return []
  }
}

function getSessionStatus(sessionName: string, currentActiveSession: string | null) {
  if (sessionName === "Daily" || sessionName === "Weekly" || sessionName === "Monthly") {
    return { status: "", color: "text-purple-300/80", isActive: false }
  }

  if (currentActiveSession === sessionName) {
    return { status: "ACTIVE SESSION", color: "text-green-400", isActive: true }
  }

  const incomingSessions = getIncomingSessions(currentActiveSession)
  if (incomingSessions.includes(sessionName)) {
    return { status: "INCOMING SESSION", color: "text-orange-400", isActive: false }
  }

  return { status: "COMPLETED SESSION", color: "text-purple-300/80", isActive: false }
}

function getSessionTimeRange(sessionName: string) {
  switch (sessionName) {
    case "Asia Session":
      return "8:00 PM - 12:00 AM"
    case "London Session":
      return "2:00 AM - 8:00 AM"
    case "New York Session":
      return "8:00 AM - 5:00 PM"
    default:
      return ""
  }
}

function getYesterdayDate() {
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  return yesterday.toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
  })
}

function getLastWeekRange() {
  const now = new Date()
  const lastWeekEnd = new Date(now)
  lastWeekEnd.setDate(now.getDate() - now.getDay()) // Last Sunday
  const lastWeekStart = new Date(lastWeekEnd)
  lastWeekStart.setDate(lastWeekEnd.getDate() - 6) // Previous Monday

  return `${lastWeekStart.toLocaleDateString("en-US", { month: "short", day: "numeric" })} - ${lastWeekEnd.toLocaleDateString("en-US", { month: "short", day: "numeric" })}`
}

function getPreviousMonthInfo() {
  const now = new Date()
  const previousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  return previousMonth.toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  })
}

function SessionMiniChart({ session, currentPrice }: { session: SessionData; currentPrice: number }) {
  const [priceData, setPriceData] = useState<Array<{ time: string; price: number; timestamp: number }>>([])
  const [currentActiveSession, setCurrentActiveSession] = useState<string | null>(null)

  useEffect(() => {
    const updateActiveSession = () => {
      setCurrentActiveSession(getCurrentSession())
    }

    updateActiveSession()
    const sessionInterval = setInterval(updateActiveSession, 60000) // Check every minute

    return () => clearInterval(sessionInterval)
  }, [])

  const generatePriceData = () => {
    const data = []
    const now = Date.now()
    const duration = 4 * 60 * 60 * 1000 // 4 hours in milliseconds
    const intervals = 60 // More data points for smoother curves

    const greenLineLevel = session.high - (session.high - session.low) * 0.15
    const constrainedHigh = greenLineLevel - (session.high - session.low) * 0.02 // Stay below green line
    const constrainedLow = session.low + (session.high - session.low) * 0.05 // Stay above red line

    const getSessionPattern = (progress: number, sessionName: string) => {
      const range = constrainedHigh - constrainedLow // Use constrained range

      switch (sessionName) {
        case "Asia Session":
          // Asia: Small, choppy consolidation with occasional breakouts (10-20 pips)
          const asiaBase = 0.3 + 0.4 * progress // Slight upward bias
          const asiaChop = Math.sin(progress * Math.PI * 12) * 0.15 // High frequency chop
          const asiaSpike = progress > 0.7 && progress < 0.8 ? Math.sin((progress - 0.7) * Math.PI * 10) * 0.3 : 0 // Occasional spike
          const asiaNoise = (Math.random() - 0.5) * 0.1 // Small random movements

          // Ensure we stay within constrained bounds
          if (progress < 0.1) return 0.1 + asiaNoise // Start near constrained low
          if (progress > 0.75 && progress < 0.85) return 0.85 + asiaNoise * 0.5 // Touch constrained high

          return Math.max(0.1, Math.min(0.9, asiaBase + asiaChop + asiaSpike + asiaNoise))

        case "Previous Daily":
          // Daily: Trending movement with pullbacks (30-50 pips)
          const dailyTrend = 0.2 + 0.6 * Math.pow(progress, 1.5) // Strong upward trend
          const dailyPullback = Math.sin(progress * Math.PI * 6) * 0.2 * (1 - progress) // Decreasing pullbacks
          const dailyMomentum = Math.sin(progress * Math.PI * 3) * 0.15 // Medium frequency waves
          const dailyNoise = (Math.random() - 0.5) * 0.08

          // Ensure we stay within constrained bounds
          if (progress < 0.05) return 0.15 + dailyNoise // Start within bounds
          if (progress > 0.85) return 0.85 + dailyNoise * 0.5 // End within bounds

          return Math.max(0.1, Math.min(0.9, dailyTrend + dailyPullback + dailyMomentum + dailyNoise))

        case "Previous Weekly":
          // Weekly: Large swings with major trend reversals (100+ pips)
          const weeklyMajorTrend = progress < 0.4 ? 0.8 - 1.5 * progress : 0.2 + 1.8 * (progress - 0.4) // Major reversal
          const weeklySwing = Math.sin(progress * Math.PI * 2.5) * 0.3 // Large swings
          const weeklyVolatility = Math.cos(progress * Math.PI * 8) * 0.15 // Medium frequency volatility
          const weeklyNoise = (Math.random() - 0.5) * 0.06

          // Ensure we stay within constrained bounds
          if (progress < 0.08) return 0.8 + weeklyNoise // Start within bounds
          if (progress > 0.35 && progress < 0.45) return 0.15 + weeklyNoise // Touch constrained low during reversal
          if (progress > 0.92) return 0.85 + weeklyNoise * 0.5 // End within bounds

          return Math.max(0.1, Math.min(0.9, weeklyMajorTrend + weeklySwing + weeklyVolatility + weeklyNoise))

        case "London Session":
          // London: Medium volatility with some directional bias (20-30 pips)
          const londonBias = progress < 0.5 ? 0.4 + 0.4 * progress : 0.6 - 0.4 * (progress - 0.5) // Directional bias
          const londonVolatility = Math.sin(progress * Math.PI * 4) * 0.2 // Medium frequency volatility
          const londonNoise = (Math.random() - 0.5) * 0.1 // Small random movements

          // Ensure we stay within constrained bounds
          if (progress < 0.1) return 0.25 + londonNoise // Start within bounds
          if (progress > 0.8) return 0.75 + londonNoise * 0.5 // End within bounds

          return Math.max(0.2, Math.min(0.8, londonBias + londonVolatility + londonNoise))

        case "New York Session":
          // New York: High volatility with strong directional bias (30-40 pips)
          const nyBias = progress < 0.5 ? 0.3 + 0.5 * progress : 0.7 - 0.5 * (progress - 0.5) // Strong directional bias
          const nyVolatility = Math.sin(progress * Math.PI * 4) * 0.3 // High frequency volatility
          const nyNoise = (Math.random() - 0.5) * 0.1 // Small random movements

          // Ensure we stay within constrained bounds
          if (progress < 0.1) return 0.2 + nyNoise // Start within bounds
          if (progress > 0.8) return 0.8 + nyNoise * 0.5 // End within bounds

          return Math.max(0.15, Math.min(0.85, nyBias + nyVolatility + nyNoise))

        case "Monthly":
          // Monthly: Very large swings with strong trend reversals (200+ pips)
          const monthlyMajorTrend = progress < 0.3 ? 0.9 - 2 * progress : 0.1 + 2 * (progress - 0.3) // Strong reversal
          const monthlySwing = Math.sin(progress * Math.PI * 2) * 0.4 // Very large swings
          const monthlyVolatility = Math.cos(progress * Math.PI * 6) * 0.2 // High frequency volatility
          const monthlyNoise = (Math.random() - 0.5) * 0.05

          // Ensure we stay within constrained bounds
          if (progress < 0.1) return 0.85 + monthlyNoise // Start within bounds
          if (progress > 0.25 && progress < 0.35) return 0.15 + monthlyNoise // Touch constrained low during reversal
          if (progress > 0.85) return 0.8 + monthlyNoise * 0.5 // End within bounds

          return Math.max(0.1, Math.min(0.9, monthlyMajorTrend + monthlySwing + monthlyVolatility + monthlyNoise))

        default:
          return 0.5 + Math.sin(progress * Math.PI * 4) * 0.3 + (Math.random() - 0.5) * 0.2
      }
    }

    for (let i = 0; i <= intervals; i++) {
      const progress = i / intervals
      const timestamp = now - duration + duration * progress
      const time = new Date(timestamp).toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      })

      // Get normalized pattern (0-1) and scale to constrained price range
      const normalizedPattern = getSessionPattern(progress, session.name)
      const price = constrainedLow + (constrainedHigh - constrainedLow) * normalizedPattern

      const finalPrice = Math.max(constrainedLow, Math.min(constrainedHigh, price))

      data.push({
        time,
        price: Number(finalPrice.toFixed(5)),
        timestamp,
      })
    }
    return data
  }

  useEffect(() => {
    const initialData = generatePriceData()
    setPriceData(initialData)

    // Only start real-time updates if this session is currently active
    const isSessionActive =
      currentActiveSession === session.name ||
      session.name === "Daily" ||
      session.name === "Weekly" ||
      session.name === "Monthly"

    if (!isSessionActive) {
      return // Don't animate inactive sessions
    }

    const getUpdateInterval = () => {
      switch (session.name) {
        case "Asia Session":
          return 500 // Keep same speed
        case "London Session":
          return 600 // Medium speed
        case "New York Session":
          return 450 // Fast speed
        case "Daily":
          return 725 // Slow down by 45% (500 * 1.45)
        case "Weekly":
          return 850 // Slow down by 70% (500 * 1.70)
        case "Monthly":
          return 1000 // Very slow speed
        default:
          return 500
      }
    }

    const interval = setInterval(() => {
      setPriceData((prevData) => {
        const newData = [...prevData]
        const lastPrice = newData[newData.length - 1].price
        const now = Date.now()
        const time = new Date(now).toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        })

        const greenLineLevel = session.high - (session.high - session.low) * 0.15
        const constrainedHigh = greenLineLevel - (session.high - session.low) * 0.02
        const constrainedLow = session.low + (session.high - session.low) * 0.05

        const momentum = Math.random() > 0.5 ? 1 : -1
        const priceChange = momentum * (Math.random() * session.range * 0.15 + session.range * 0.05)
        const newPrice = Math.max(constrainedLow, Math.min(constrainedHigh, lastPrice + priceChange))

        // Remove oldest point and add new one
        newData.shift()
        newData.push({ time, price: Number(newPrice.toFixed(5)), timestamp: now })

        return newData
      })
    }, getUpdateInterval())

    return () => clearInterval(interval)
  }, [session, currentActiveSession])

  return (
    <div className="relative w-full h-72 bg-black/20 rounded-xl border border-white/10 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-500/5 via-purple-500/10 to-purple-500/15" />

      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={priceData} margin={{ top: 0, right: 0, left: -70, bottom: 0 }}>
          <defs>
            <linearGradient id={`sessionGradient-${session.name}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(168, 85, 247, 0.6)" />
              <stop offset="50%" stopColor="rgba(168, 85, 247, 0.3)" />
              <stop offset="100%" stopColor="rgba(168, 85, 247, 0.1)" />
            </linearGradient>
          </defs>

          <XAxis
            dataKey="time"
            axisLine={false}
            tickLine={false}
            tick={false}
            domain={["dataMin", "dataMax"]}
            padding={{ left: 0, right: 0 }}
          />
          <YAxis domain={[session.low, session.high]} axisLine={false} tickLine={false} tick={false} />

          <ReferenceLine
            y={session.high - (session.high - session.low) * 0.15}
            stroke="rgba(34, 197, 94, 0.8)"
            strokeWidth={1.5}
            strokeDasharray="6 3"
          />
          <ReferenceLine y={session.low} stroke="rgba(239, 68, 68, 0.8)" strokeWidth={1.5} strokeDasharray="6 3" />

          <Area
            type="monotone"
            dataKey="price"
            stroke="#a855f7"
            strokeWidth={2.5}
            fill={`url(#sessionGradient-${session.name})`}
            dot={false}
            connectNulls={true}
            activeDot={{
              r: 4,
              fill: "#a855f7",
              stroke: "#ffffff",
              strokeWidth: 2,
            }}
          />
        </AreaChart>
      </ResponsiveContainer>

      <div
        className="absolute right-3 text-xs text-green-400 font-mono bg-black/70 px-2 py-1 rounded-md border border-green-400/30"
        style={{ top: "5%" }} // moved green text up by half inch from 15% to 5%
      >
        {session.high.toFixed(5)}
      </div>
      <div className="absolute bottom-2 right-3 text-xs text-red-400 font-mono bg-black/70 px-2 py-1 rounded-md border border-red-400/30">
        {session.low.toFixed(5)}
      </div>

      {currentPrice >= session.low && currentPrice <= session.high && (
        <div
          className="absolute right-0 w-3 h-1 bg-yellow-400 shadow-lg shadow-yellow-400/50 rounded-l-full"
          style={{
            top: `${((session.high - currentPrice) / session.range) * 100}%`,
          }}
        />
      )}
    </div>
  )
}

function SessionCard({ session, index, currentPrice }: { session: SessionData; index: number; currentPrice: number }) {
  const [currentActiveSession, setCurrentActiveSession] = useState<string | null>(null)

  useEffect(() => {
    const updateActiveSession = () => {
      setCurrentActiveSession(getCurrentSession())
    }

    updateActiveSession()
    const sessionInterval = setInterval(updateActiveSession, 60000)

    return () => clearInterval(sessionInterval)
  }, [])

  const isAboveHigh = currentPrice > session.high
  const isBelowLow = currentPrice < session.low
  const isInRange = currentPrice >= session.low && currentPrice <= session.high

  const sessionStatus = getSessionStatus(session.name, currentActiveSession)
  const isCurrentlyActive = sessionStatus.isActive
  const isIncoming = sessionStatus.status === "INCOMING SESSION"

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: index * 0.15, type: "spring", damping: 20 }}
      className="premium-glass-panel relative overflow-hidden group"
      style={{
        background: `linear-gradient(135deg, ${session.color}, ${session.color.replace("0.2", "0.1")})`,
        borderColor: session.borderColor,
      }}
    >
      {/* Animated background particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 8 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full opacity-30"
            style={{ backgroundColor: session.borderColor }}
            initial={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -10, 0],
              opacity: [0.3, 0.8, 0.3],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="p-6 relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center border backdrop-blur-sm ${
                isCurrentlyActive ? "animate-pulse" : ""
              }`}
              style={{
                backgroundColor: session.color,
                borderColor: session.borderColor,
              }}
            >
              <Clock className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">{session.name}</h3>
              <div className="space-y-1">
                {session.name.includes("Session") && (
                  <p className="text-xs text-purple-300/80">{getSessionTimeRange(session.name)}</p>
                )}
                {session.name === "Daily" && (
                  <p className="text-xs text-purple-300/80">Previous Daily - {getYesterdayDate()}</p>
                )}
                {session.name === "Weekly" && (
                  <p className="text-xs text-purple-300/80">Last Week - {getLastWeekRange()}</p>
                )}
                {session.name === "Monthly" && (
                  <p className="text-xs text-purple-300/80">Previous Month - {getPreviousMonthInfo()}</p>
                )}
                {sessionStatus.status && (
                  <p className={`text-xs font-medium ${sessionStatus.color}`}>{sessionStatus.status}</p>
                )}
                {isIncoming && <p className="text-xs text-orange-300/70">Previous {session.name} High/Low</p>}
              </div>
            </div>
          </div>
          {isCurrentlyActive && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-xs font-medium">LIVE</span>
            </div>
          )}
          {isIncoming && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
              <span className="text-orange-400 text-xs font-medium">NEXT</span>
            </div>
          )}
        </div>

        {/* Main session data */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <motion.div
            className="flex items-center justify-between p-3 rounded-xl bg-black/20 backdrop-blur-sm border border-white/10 group-hover:bg-black/30 transition-all duration-300"
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-green-400 font-medium text-sm">High</span>
            </div>
            <div className="text-right">
              <div className="text-white font-mono text-sm">{session.high.toFixed(5)}</div>
              {isAboveHigh && !isIncoming && <div className="text-green-400 text-xs">BROKEN ↑</div>}
            </div>
          </motion.div>

          <motion.div
            className="flex items-center justify-between p-3 rounded-xl bg-black/20 backdrop-blur-sm border border-white/10 group-hover:bg-black/30 transition-all duration-300"
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-red-400" />
              <span className="text-red-400 font-medium text-sm">Low</span>
            </div>
            <div className="text-right">
              <div className="text-white font-mono text-sm">{session.low.toFixed(5)}</div>
              {isBelowLow && !isIncoming && <div className="text-red-400 text-xs">BROKEN ↓</div>}
            </div>
          </motion.div>
        </div>

        {/* Session chart */}
        <div className="mb-4">
          <SessionMiniChart session={session} currentPrice={currentPrice} />
        </div>

        {/* Always visible content - no dropdown animation */}
        <div className="pt-4 border-t border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-purple-300 text-sm">Range</span>
            <span className="text-white font-mono text-sm">{(session.range * 10000).toFixed(1)} pips</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-purple-300 text-sm">Open</span>
            <span className="text-white font-mono text-sm">{session.open.toFixed(5)}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-purple-300 text-sm">Close</span>
            <span className="text-white font-mono text-sm">{session.close.toFixed(5)}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-purple-300 text-sm">Current Status</span>
            <div className="flex items-center gap-2">
              {!isIncoming && (
                <>
                  <div
                    className={`w-2 h-2 rounded-full ${
                      isInRange ? "bg-yellow-400" : isAboveHigh ? "bg-green-400" : "bg-red-400"
                    }`}
                  />
                  <span
                    className={`text-xs font-medium ${
                      isInRange ? "text-yellow-400" : isAboveHigh ? "text-green-400" : "text-red-400"
                    }`}
                  >
                    {isInRange ? "IN RANGE" : isAboveHigh ? "ABOVE HIGH" : "BELOW LOW"}
                  </span>
                </>
              )}
              {isIncoming && (
                <>
                  <div className="w-2 h-2 rounded-full bg-orange-400 animate-pulse" />
                  <span className="text-xs font-medium text-orange-400">AWAITING OPEN</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Hover effect overlay */}
      <motion.div
        className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          background: `linear-gradient(135deg, ${session.borderColor.replace("0.6", "0.1")}, transparent)`,
        }}
      />
    </motion.div>
  )
}

function SessionOverview({ analysis }: { analysis: SessionAnalysis }) {
  const sessions = [analysis.asiaSession, analysis.previousDaily, analysis.previousWeekly]

  const getMarketBias = () => {
    let bullishCount = 0
    let bearishCount = 0

    sessions.forEach((session) => {
      if (analysis.currentPrice > session.high) bullishCount++
      if (analysis.currentPrice < session.low) bearishCount++
    })

    if (bullishCount > bearishCount) return { bias: "BULLISH", color: "text-green-400", confidence: bullishCount * 33 }
    if (bearishCount > bullishCount) return { bias: "BEARISH", color: "text-red-400", confidence: bearishCount * 33 }
    return { bias: "NEUTRAL", color: "text-yellow-400", confidence: 50 }
  }

  const marketBias = getMarketBias()

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.5 }}
      className="premium-glass-panel p-6 bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-500/30 hover:scale-[1.01] transition-all duration-300"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/30 to-blue-500/30 flex items-center justify-center border border-purple-500/40">
          <Activity className="w-6 h-6 text-purple-300" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Session Analysis Overview</h3>
          <p className="text-purple-300/80 text-sm">Multi-Session Price Action Analysis</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <motion.div
            className="flex items-center justify-between hover:bg-white/5 p-2 rounded-lg transition-colors"
            whileHover={{ x: 5 }}
          >
            <span className="text-purple-300">Current Price</span>
            <span className="text-white font-mono text-lg">{analysis.currentPrice.toFixed(5)}</span>
          </motion.div>

          <motion.div
            className="flex items-center justify-between hover:bg-white/5 p-2 rounded-lg transition-colors"
            whileHover={{ x: 5 }}
          >
            <span className="text-purple-300">Market Bias</span>
            <div className="flex items-center gap-2">
              <span className={`font-bold ${marketBias.color}`}>{marketBias.bias}</span>
              <div className="w-16 h-2 bg-purple-900/30 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${marketBias.confidence}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>
            </div>
          </motion.div>
        </div>

        <div className="space-y-4">
          <motion.div
            className="flex items-center justify-between hover:bg-white/5 p-2 rounded-lg transition-colors"
            whileHover={{ x: 5 }}
          >
            <span className="text-purple-300">Active Sessions</span>
            <span className="text-white font-bold">
              {sessions.filter((s) => s.isActive).length}/{sessions.length}
            </span>
          </motion.div>

          <motion.div
            className="flex items-center justify-between hover:bg-white/5 p-2 rounded-lg transition-colors"
            whileHover={{ x: 5 }}
          >
            <span className="text-purple-300">Key Levels</span>
            <span className="text-white font-bold">{sessions.length * 2} Levels</span>
          </motion.div>
        </div>
      </div>

      <div className="mt-6 pt-4 border-t border-purple-500/20">
        <div className="flex items-center justify-center">
          <motion.div
            className={`px-4 py-2 rounded-xl font-semibold text-sm border ${
              marketBias.confidence > 66
                ? `${marketBias.color.replace("text-", "bg-").replace("-400", "-500/20")} ${marketBias.color.replace("text-", "border-").replace("-400", "-500/30")}`
                : "bg-purple-500/20 text-purple-400 border-purple-500/30"
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {marketBias.confidence > 66 ? `HIGH CONFIDENCE ${marketBias.bias}` : `MIXED SIGNALS - ${marketBias.bias}`}
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}

export function SessionAnalysisDisplay({ analysis, isLoading }: SessionAnalysisDisplayProps) {
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="premium-glass-panel p-6 animate-pulse">
              <div className="h-4 bg-purple-500/20 rounded mb-4"></div>
              <div className="space-y-3">
                <div className="h-12 bg-purple-500/10 rounded"></div>
                <div className="h-12 bg-purple-500/10 rounded"></div>
                <div className="h-32 bg-purple-500/10 rounded"></div>
                <div className="h-8 bg-purple-500/10 rounded"></div>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[4, 5, 6].map((i) => (
            <div key={i} className="premium-glass-panel p-6 animate-pulse">
              <div className="h-4 bg-purple-500/20 rounded mb-4"></div>
              <div className="space-y-3">
                <div className="h-12 bg-purple-500/10 rounded"></div>
                <div className="h-12 bg-purple-500/10 rounded"></div>
                <div className="h-32 bg-purple-500/10 rounded"></div>
                <div className="h-8 bg-purple-500/10 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (!analysis) {
    return (
      <div className="text-center py-12">
        <p className="text-purple-300">No session analysis data available</p>
      </div>
    )
  }

  const tradingSessions = [
    {
      ...analysis.asiaSession,
      name: "Asia Session",
    },
    {
      ...analysis.asiaSession,
      name: "London Session",
      high: analysis.asiaSession.high + 0.0015,
      low: analysis.asiaSession.low + 0.0008,
      open: analysis.asiaSession.open + 0.001,
      close: analysis.asiaSession.close + 0.0012,
      color: "rgba(59, 130, 246, 0.2)", // Blue theme for London
      borderColor: "rgba(59, 130, 246, 0.6)",
    },
    {
      ...analysis.asiaSession,
      name: "New York Session",
      high: analysis.asiaSession.high + 0.0025,
      low: analysis.asiaSession.low - 0.0005,
      open: analysis.asiaSession.open + 0.0005,
      close: analysis.asiaSession.close + 0.002,
      color: "rgba(34, 197, 94, 0.2)", // Green theme for NY
      borderColor: "rgba(34, 197, 94, 0.6)",
    },
  ]

  const timeframeSessions = [
    {
      ...analysis.previousDaily,
      name: "Daily",
    },
    {
      ...analysis.previousWeekly,
      name: "Weekly",
    },
    {
      ...analysis.previousWeekly,
      name: "Monthly",
      high: analysis.previousWeekly.high + 0.005,
      low: analysis.previousWeekly.low - 0.003,
      open: analysis.previousWeekly.open - 0.001,
      close: analysis.previousWeekly.close + 0.004,
      color: "rgba(245, 158, 11, 0.2)", // Amber theme for Monthly
      borderColor: "rgba(245, 158, 11, 0.6)",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tradingSessions.map((session, index) => (
          <SessionCard key={session.name} session={session} index={index} currentPrice={analysis.currentPrice} />
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {timeframeSessions.map((session, index) => (
          <SessionCard key={session.name} session={session} index={index + 3} currentPrice={analysis.currentPrice} />
        ))}
      </div>

      <SessionOverview analysis={analysis} />
    </div>
  )
}
