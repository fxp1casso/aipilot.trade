"use client"

import type React from "react"
import { useCallback, useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Users, X, Target, MessageSquare, LineChart, Globe, BarChart3, Coins, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { CommunityChat } from "./community-chat"
import { ForecastRoom } from "./community/forecast-room"
import type { StudentForecast } from "./student-forecast-system"

/**
 * Premium Sliding Community Hub - Completely Rebuilt
 * - True left-to-right sliding drawer animation
 * - Maximized content area using full extended dimensions
 * - Sophisticated glass morphism with enhanced hover effects
 * - Slides from left edge like a proper dropdown/drawer
 */

type SectionId = "overview" | "fx-heatmap" | "indices" | "crypto" | "forecasts" | "chat"

const SECTIONS: Array<{
  id: SectionId
  label: string
  icon: React.ComponentType<{ className?: string }>
  accent?: string
}> = [
  { id: "overview", label: "Market Overview", icon: LineChart, accent: "text-purple-300" },
  { id: "fx-heatmap", label: "FX Heatmap", icon: Globe, accent: "text-emerald-300" },
  { id: "indices", label: "Indices", icon: BarChart3, accent: "text-amber-300" },
  { id: "crypto", label: "Crypto", icon: Coins, accent: "text-sky-300" },
  { id: "forecasts", label: "Forecast Room", icon: Target, accent: "text-rose-300" },
  { id: "chat", label: "Live Chat", icon: MessageSquare, accent: "text-zinc-300" },
]

export function FloatingCommunityHub() {
  const [isOpen, setIsOpen] = useState(false)
  const [active, setActive] = useState<SectionId>("overview")
  const [hasNewForecast, setHasNewForecast] = useState(false)
  const [newForecasts, setNewForecasts] = useState<StudentForecast[]>([])
  const [lastToast, setLastToast] = useState<StudentForecast | null>(null)
  const [showNotif, setShowNotif] = useState(false)

  const handleNewForecast = useCallback((event: Event) => {
    const customEvent = event as CustomEvent
    const newForecast = customEvent.detail as StudentForecast
    setNewForecasts((prev) => [newForecast, ...prev])
    setLastToast(newForecast)
    setShowNotif(true)
    setHasNewForecast(true)
    const t = setTimeout(() => setShowNotif(false), 4200)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    window.addEventListener("forecast:submitted", handleNewForecast)
    return () => window.removeEventListener("forecast:submitted", handleNewForecast)
  }, [handleNewForecast])

  const drawerVariants = {
    initial: {
      x: "-100%",
      opacity: 0,
      transition: { type: "spring", stiffness: 400, damping: 30 },
    },
    animate: {
      x: "0%",
      opacity: 1,
      transition: { type: "spring", stiffness: 300, damping: 25, mass: 0.8 },
    },
    exit: {
      x: "-100%",
      opacity: 0,
      transition: { type: "spring", stiffness: 400, damping: 30, mass: 0.6 },
    },
  }

  function GlassChartCard({
    title,
    subtitle,
    glow,
    children,
  }: {
    title: string
    subtitle?: string
    glow?: "purple" | "emerald" | "amber" | "sky"
    children?: React.ReactNode
  }) {
    const glowCls =
      glow === "emerald"
        ? "hover:shadow-[0_0_20px_rgba(16,185,129,0.25)]"
        : glow === "amber"
          ? "hover:shadow-[0_0_20px_rgba(245,158,11,0.22)]"
          : glow === "sky"
            ? "hover:shadow-[0_0_20px_rgba(56,189,248,0.22)]"
            : "hover:shadow-[0_0_24px_rgba(147,51,234,0.26)]"

    return (
      <motion.div
        whileHover={{
          y: -2,
          scale: 1.01,
          transition: { type: "spring", stiffness: 400, damping: 25 },
        }}
        className={`relative overflow-hidden rounded-lg bg-gradient-to-br from-zinc-900/80 via-zinc-900/60 to-zinc-800/40 backdrop-blur-xl border border-zinc-700/50 hover:border-purple-500/40 p-2.5 transition-all duration-300 ${glowCls}`}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-white/3 via-transparent to-purple-500/3 opacity-0 hover:opacity-100 transition-opacity duration-300" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <div>
              <div className="text-xs font-semibold text-white tracking-tight">{title}</div>
              {subtitle && <div className="text-[10px] text-zinc-400 mt-0.5">{subtitle}</div>}
            </div>
            <Info className="w-3 h-3 text-zinc-400 hover:text-purple-300 transition-colors" />
          </div>

          <div className="rounded-md border border-zinc-800/70 overflow-hidden bg-zinc-950/40 backdrop-blur-sm">
            {children ?? (
              <div className="h-20 w-full relative">
                <motion.div
                  className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-transparent via-purple-400/60 to-transparent"
                  initial={{ x: "-100%" }}
                  animate={{ x: ["-100%", "100%"] }}
                  transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                />
                <img
                  src="/placeholder.svg?height=80&width=200"
                  alt="Premium glass chart placeholder"
                  className="w-full h-full object-cover opacity-90"
                />
              </div>
            )}
          </div>
        </div>
      </motion.div>
    )
  }

  function SectionContent() {
    if (active === "overview") {
      return (
        <div className="grid grid-cols-2 gap-2 h-full">
          <GlassChartCard title="Instruments" subtitle="FX • Indices • Crypto" glow="purple" />
          <GlassChartCard title="Session Flow" subtitle="London • NY • Asia" glow="emerald" />
          <GlassChartCard title="Volatility" subtitle="24h implied vs realized" glow="amber" />
          <GlassChartCard title="Macro Pulse" subtitle="DXY • Yields • Gold" glow="sky" />
          <GlassChartCard title="Market Sentiment" subtitle="Risk On/Off" glow="purple" />
          <GlassChartCard title="Economic Events" subtitle="High Impact" glow="emerald" />
        </div>
      )
    }
    if (active === "fx-heatmap") {
      return (
        <div className="grid grid-cols-2 gap-2 h-full">
          <GlassChartCard title="FX Heatmap" subtitle="Majors performance" glow="emerald" />
          <GlassChartCard title="EURUSD" subtitle="Liquidity • Sweeps" glow="purple" />
          <GlassChartCard title="GBPUSD" subtitle="Premium/Discount" glow="amber" />
          <GlassChartCard title="USDJPY" subtitle="Session ranges" glow="sky" />
          <GlassChartCard title="AUDUSD" subtitle="Commodity correlation" glow="emerald" />
          <GlassChartCard title="USDCAD" subtitle="Oil correlation" glow="amber" />
        </div>
      )
    }
    if (active === "indices") {
      return (
        <div className="grid grid-cols-2 gap-2 h-full">
          <GlassChartCard title="US Indices" subtitle="SPX • NDX • DJIA" glow="purple" />
          <GlassChartCard title="EU Indices" subtitle="DAX • CAC" glow="emerald" />
          <GlassChartCard title="Volatility" subtitle="VIX trend" glow="amber" />
          <GlassChartCard title="Breadth" subtitle="Adv/Dec • NH/NL" glow="sky" />
          <GlassChartCard title="Futures" subtitle="ES • NQ • YM" glow="purple" />
          <GlassChartCard title="Sectors" subtitle="Tech • Finance • Energy" glow="emerald" />
        </div>
      )
    }
    if (active === "crypto") {
      return (
        <div className="grid grid-cols-2 gap-2 h-full">
          <GlassChartCard title="Majors" subtitle="BTC • ETH • SOL" glow="purple" />
          <GlassChartCard title="BTC Liquidity" subtitle="LTF imbalances" glow="emerald" />
          <GlassChartCard title="ETH Bias" subtitle="Structure • BOS" glow="amber" />
          <GlassChartCard title="Alt Pulse" subtitle="Alt rotations" glow="sky" />
          <GlassChartCard title="DeFi Tokens" subtitle="UNI • AAVE • COMP" glow="purple" />
          <GlassChartCard title="Layer 1s" subtitle="ADA • DOT • AVAX" glow="emerald" />
        </div>
      )
    }
    if (active === "forecasts") {
      return (
        <div className="h-full flex flex-col">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-white">Forecast Room</div>
              <div className="text-xs text-zinc-400">Connected to Student Hub • live updates</div>
            </div>
            {hasNewForecast && (
              <span className="inline-flex items-center gap-1 text-xs text-amber-200">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-300 opacity-60" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400" />
                </span>
                New
              </span>
            )}
          </div>
          <div className="flex-1 rounded-lg bg-gradient-to-br from-zinc-900/80 via-zinc-900/60 to-zinc-800/40 backdrop-blur-xl border border-zinc-700/50 p-2 overflow-hidden">
            <div className="h-full overflow-auto">
              <ForecastRoom forecasts={newForecasts} />
            </div>
          </div>
        </div>
      )
    }
    if (active === "chat") {
      return (
        <div className="h-full flex flex-col">
          <div className="mb-2 text-sm font-semibold text-white">Live Community Chat</div>
          <div className="flex-1 rounded-lg bg-gradient-to-br from-zinc-900/80 via-zinc-900/60 to-zinc-800/40 backdrop-blur-xl border border-zinc-700/50 p-2 overflow-hidden">
            <CommunityChat />
          </div>
        </div>
      )
    }
    return null
  }

  function IconRail() {
    return (
      <TooltipProvider delayDuration={80}>
        <div className="flex items-center gap-1.5 rounded-lg bg-zinc-900/60 border border-zinc-800/70 px-2 py-1.5 backdrop-blur-xl">
          {SECTIONS.map((s) => {
            const Icon = s.icon
            const isActive = active === s.id
            return (
              <Tooltip key={s.id}>
                <TooltipTrigger asChild>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onMouseEnter={() => setActive(s.id)}
                    onFocus={() => setActive(s.id)}
                    onClick={() => setActive(s.id)}
                    className={[
                      "relative p-1.5 rounded-md transition-all duration-200",
                      "hover:bg-zinc-800/80 focus:bg-zinc-800/80",
                      isActive
                        ? "bg-purple-500/20 border border-purple-500/40 shadow-lg shadow-purple-500/20"
                        : "border border-transparent",
                    ].join(" ")}
                    aria-pressed={isActive}
                    aria-label={s.label}
                    title={s.label}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="hub-active-glow"
                        className="absolute inset-0 rounded-md bg-gradient-to-br from-purple-500/15 to-purple-600/10"
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                    <Icon className={`w-3.5 h-3.5 relative ${s.accent ?? "text-zinc-300"}`} />
                  </motion.button>
                </TooltipTrigger>
                <TooltipContent
                  side="bottom"
                  className="bg-zinc-900/90 backdrop-blur-xl border border-zinc-700/50 px-2 py-1 text-xs"
                >
                  {s.label}
                </TooltipContent>
              </Tooltip>
            )
          })}
        </div>
      </TooltipProvider>
    )
  }

  return (
    <>
      <div className="fixed top-24 left-0 z-50">
        <AnimatePresence initial={false}>
          {!isOpen && (
            <motion.button
              key="hub-trigger"
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1, transition: { type: "spring", stiffness: 300, damping: 25 } }}
              exit={{ x: -20, opacity: 0, transition: { duration: 0.15 } }}
              onMouseEnter={() => setIsOpen(true)}
              className="relative p-3 rounded-r-xl bg-gradient-to-br from-zinc-900/90 via-zinc-800/80 to-zinc-900/90 backdrop-blur-xl border-r border-t border-b border-purple-500/30 text-zinc-200 hover:text-white shadow-xl hover:shadow-purple-500/20 transition-all duration-200"
              aria-label="Open Community Hub"
              title="Community Hub"
            >
              <Users className="w-5 h-5 text-purple-300" />
              {hasNewForecast && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-300 opacity-70" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-400" />
                </span>
              )}
            </motion.button>
          )}
        </AnimatePresence>

        <AnimatePresence initial={false}>
          {isOpen && (
            <motion.div
              key="hub-drawer"
              variants={drawerVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="fixed left-0 top-16 w-[23vw] min-w-[320px] max-w-[450px] h-[80vh] bg-gradient-to-br from-zinc-900/95 via-zinc-800/90 to-zinc-900/95 backdrop-blur-2xl border-r border-t border-b border-purple-500/30 shadow-2xl shadow-black/40 rounded-r-2xl overflow-hidden"
              role="dialog"
              aria-modal="true"
              aria-label="Community Hub"
              onMouseLeave={() => setIsOpen(false)}
            >
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-2 right-2 z-20 p-1.5 rounded-full text-zinc-400 hover:bg-white/10 hover:text-white transition-all duration-200 hover:scale-110"
                aria-label="Close Community Hub"
              >
                <X className="w-4 h-4" />
              </button>

              <AnimatePresence>
                {showNotif && lastToast && (
                  <motion.div
                    key="hub-toast"
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -20, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    className="absolute top-3 left-1/2 -translate-x-1/2 z-20"
                  >
                    <div className="px-3 py-2 rounded-lg border border-amber-300/40 bg-zinc-900/90 backdrop-blur-xl shadow-xl">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="inline-flex h-2 w-2 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]" />
                        <span className="text-amber-200 font-medium">New: {lastToast.pair}</span>
                        <span className="text-zinc-400">•</span>
                        <span className="text-zinc-300">{lastToast.direction}</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="relative z-10 px-3 pt-3 pb-2 border-b border-zinc-800/70">
                <div className="flex items-center justify-center">
                  <IconRail />
                </div>
              </div>

              <div className="h-[calc(80vh-60px)] p-3 overflow-y-auto">
                <SectionContent />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  )
}
