"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import { Waves, Search, ChevronDown, Activity, Bot, BarChart3, Users, TrendingUp, History } from "lucide-react"
import { TradingViewWidget } from "@/components/trading-view-widget"
import { FloatingConfluencePanel } from "@/components/floating-confluence-panel"
import { FloatingScenarioPanel } from "@/components/floating-scenario-panel"
import { allInstruments, instrumentsByCategory, type Instrument } from "@/lib/instruments"
import { InstrumentSearchModal } from "@/components/execution-copilot/instrument-search-modal"
import { FloatingNav } from "@/components/floating-nav"
import { EnhancedInstrumentSelector } from "@/components/enhanced-instrument-selector"
import { PremiumChartAnalysisModal } from "@/components/premium-chart-analysis-modal"
import { AnalysisHistoryModal } from "@/components/analysis-history-modal"

const getTradingViewSymbol = (instrument: Instrument) => {
  return instrument.symbol
}

const HybridInstrumentSelector = ({
  instruments,
  onSelect,
  label,
  category,
}: {
  instruments: Instrument[]
  onSelect: (instrument: Instrument) => void
  label: string
  category: string
}) => {
  const [showEnhancedSelector, setShowEnhancedSelector] = useState(false)
  const [buttonPosition, setButtonPosition] = useState<{ top: number; left: number } | undefined>()
  const [favorites, setFavorites] = useState<Instrument[]>(() => {
    const saved = localStorage.getItem(`favorites_${category}`)
    if (saved) {
      try {
        const favoriteIds = JSON.parse(saved)
        return instruments.filter((inst) => favoriteIds.includes(inst.id))
      } catch {
        return instruments.slice(0, 5)
      }
    }
    return instruments.slice(0, 5)
  })

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    setButtonPosition({
      top: rect.bottom,
      left: rect.left,
    })
    setShowEnhancedSelector(true)
  }

  const handleFavoriteSelect = (instrument: Instrument) => {
    onSelect(instrument)
  }

  const handleEnhancedSelect = (instrument: Instrument) => {
    onSelect(instrument)
    setShowEnhancedSelector(false)
  }

  const handleFavoritesUpdate = (newFavorites: Instrument[]) => {
    setFavorites(newFavorites)
    localStorage.setItem(`favorites_${category}`, JSON.stringify(newFavorites.map((f) => f.id)))
  }

  return (
    <>
      <div className="relative group">
        <div className="premium-glass-button cursor-pointer" onClick={handleClick}>
          <span className="button-text">{label}</span>
          <ChevronDown className="w-4 h-4 ml-2 transition-transform duration-300 group-hover:rotate-180" />
        </div>

        <div className="absolute top-full left-0 mt-2 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 z-50 pointer-events-none group-hover:pointer-events-auto">
          <div className="premium-glass-dropdown">
            <div className="p-2 space-y-1">
              {favorites.map((instrument) => (
                <button
                  key={instrument.id}
                  onClick={() => handleFavoriteSelect(instrument)}
                  className="dropdown-item"
                  onMouseEnter={(e) => {
                    e.currentTarget.style.setProperty("--hover-active", "1")
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.setProperty("--hover-active", "0")
                  }}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500/30 to-blue-500/30 flex items-center justify-center border border-purple-500/40 backdrop-blur-sm">
                        <span className="text-xs font-bold text-white drop-shadow-sm">
                          {instrument.symbol.substring(0, 2)}
                        </span>
                      </div>
                      <div className="text-left">
                        <div className="text-sm font-medium text-white">{instrument.symbol}</div>
                        <div className="text-xs text-gray-300">{instrument.name}</div>
                      </div>
                    </div>
                    <div className="text-xs text-purple-300 font-medium capitalize">{instrument.category}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {showEnhancedSelector && (
        <EnhancedInstrumentSelector
          instruments={instruments}
          onSelect={handleEnhancedSelect}
          onClose={() => setShowEnhancedSelector(false)}
          label={label}
          category={category}
          favorites={favorites}
          onFavoritesUpdate={handleFavoritesUpdate}
          isOpen={showEnhancedSelector}
          position={buttonPosition}
        />
      )}
    </>
  )
}

function FloatingParticles() {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {Array.from({ length: 10 }).map((_, i) => (
        <motion.span
          key={i}
          className="absolute block h-1.5 w-1.5 rounded-full bg-purple-400/30 shadow-[0_0_16px_rgba(168,85,247,0.35)]"
          style={{
            top: `${Math.random() * 90 + 5}%`,
            left: `${Math.random() * 90 + 5}%`,
          }}
          animate={{
            y: [0, Math.random() * 10 - 5, 0],
            x: [0, Math.random() * 10 - 5, 0],
            opacity: [0.4, 1, 0.4],
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 3 + Math.random() * 3,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            delay: Math.random() * 2,
          }}
        />
      ))}
    </div>
  )
}

function UtcClock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  const pad = (n: number) => String(n).padStart(2, "0")
  const t = `${pad(now.getUTCHours())}:${pad(now.getUTCMinutes())}:${pad(now.getUTCSeconds())}`
  return (
    <div className="flex items-baseline gap-2">
      <div className="text-2xl sm:text-3xl font-extrabold tracking-wider text-white tabular-nums">{t}</div>
      <div className="text-[10px] sm:text-[11px] uppercase text-zinc-400">UTC</div>
    </div>
  )
}

export function LiveMarketIntelligence() {
  const pathname = usePathname()

  const premiumMenu = [
    { title: "Signal Terminal", href: "/", icon: Activity, desc: "Real-time market analysis" },
    { title: "Execution Co-Pilot", href: "/copilot", icon: Bot, desc: "Live trade assistance" },
    { title: "MRKT Intelligence", href: "/intelligence", icon: BarChart3, desc: "Macro event analysis" },
    { title: "Student Hub", href: "/hub", icon: Users, desc: "Community & Forecasts" },
    { title: "Nexus", href: "/nexus", icon: BarChart3, desc: "Strategic Synthesis" },
  ]

  const [activeInstrument, setActiveInstrument] = useState<Instrument>(allInstruments[0])
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isAnalysisModalOpen, setAnalysisModalOpen] = useState(false)
  const [isHistoryModalOpen, setHistoryModalOpen] = useState(false)
  const [widgetKey, setWidgetKey] = useState(Date.now())

  const handleSaveAnalysis = async () => {
    try {
      const analysisName = `${activeInstrument.symbol} Analysis - ${new Date().toLocaleDateString()}`
      const description = `Comprehensive analysis of ${activeInstrument.symbol} including multi-timeframe, session, liquidity, and macro factors.`
      setHistoryModalOpen(true)
    } catch (error) {
      console.error("Failed to save analysis:", error)
    }
  }

  return (
    <>
      {isSearchOpen && (
        <InstrumentSearchModal
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
          onSelect={(inst) => {
            setActiveInstrument(inst)
            setIsSearchOpen(false)
          }}
        />
      )}
      {isAnalysisModalOpen && (
        <PremiumChartAnalysisModal
          isOpen={isAnalysisModalOpen}
          onClose={() => setAnalysisModalOpen(false)}
          activeInstrument={activeInstrument}
        />
      )}
      {isHistoryModalOpen && (
        <AnalysisHistoryModal isOpen={isHistoryModalOpen} onClose={() => setHistoryModalOpen(false)} />
      )}
      <FloatingNav />

      <div className="bg-[#0c0c10] min-h-screen h-[100dvh] flex flex-col p-4 sm:p-6 lg:p-8 relative z-0 overflow-y-auto">
        <div
          aria-hidden="true"
          className="fixed inset-0 -z-10 bg-gradient-to-br from-purple-900/5 via-transparent to-blue-900/5 pointer-events-none"
        />
        <div
          aria-hidden="true"
          className="fixed inset-0 -z-10 bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.1),transparent_50%)] tracking-normal pointer-events-none"
        />

        <div className="max-w-screen-2xl mx-auto w-full flex flex-col min-h-0 h-full relative z-10">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="h-[72px] flex-shrink-0"
          />

          <motion.div
            initial={{ opacity: 0, y: -18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col sm:flex-row justify-between sm:items-center mb-6 gap-4 flex-shrink-0"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 flex items-center justify-center border border-purple-500/30 backdrop-blur-xl">
                <Waves className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white tracking-tight">Institutional Signal Terminal</h1>
                <p className="text-gray-400 text-sm">
                  Live Confluence & Scenario Analysis for Institutional Grade Trading
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 flex-shrink-0">
              <HybridInstrumentSelector
                instruments={instrumentsByCategory.forex}
                onSelect={setActiveInstrument}
                label="Forex Pairs"
                category="forex"
              />

              <div className="h-6 w-px bg-gradient-to-b from-transparent via-purple-400/30 to-transparent" />

              <HybridInstrumentSelector
                instruments={instrumentsByCategory.indices}
                onSelect={setActiveInstrument}
                label="Indices"
                category="indices"
              />

              <div className="h-6 w-px bg-gradient-to-b from-transparent via-purple-400/30 to-transparent" />

              <HybridInstrumentSelector
                instruments={instrumentsByCategory.crypto}
                onSelect={setActiveInstrument}
                label="Crypto"
                category="crypto"
              />

              <div className="h-6 w-px bg-gradient-to-b from-transparent via-purple-400/30 to-transparent" />

              <HybridInstrumentSelector
                instruments={instrumentsByCategory.commodities}
                onSelect={setActiveInstrument}
                label="Commodities"
                category="commodities"
              />

              <div className="h-6 w-px bg-gradient-to-b from-transparent via-purple-400/30 to-transparent" />

              <button onClick={() => setIsSearchOpen(true)} className="premium-glass-icon-button">
                <Search className="w-4 h-4" />
              </button>

              <button
                onClick={() => setAnalysisModalOpen(true)}
                className="relative group premium-glass-action-button overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 via-blue-600/20 to-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                <TrendingUp className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform duration-200 relative z-10" />
                <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent font-semibold relative z-10 group-hover:from-purple-300 group-hover:to-blue-300 transition-all duration-300">
                  Analyze Charts
                </span>
                <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-500/0 via-purple-500/20 to-blue-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm" />
                <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-purple-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-md -z-10" />
              </button>

              <button
                onClick={handleSaveAnalysis}
                className="premium-glass-icon-button group relative"
                title="Analysis History"
              >
                <History className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
              </button>
            </div>
          </motion.div>

          <div className="relative flex-grow min-h-0 flex flex-col">
            <div className="flex-grow min-h-0 premium-glass-chart-container mb-2">
              <div className="h-full p-1">
                <TradingViewWidget key={widgetKey} symbol={getTradingViewSymbol(activeInstrument)} />
              </div>
            </div>

            <FloatingConfluencePanel activeInstrument={activeInstrument.id} />
            <FloatingScenarioPanel activeInstrument={activeInstrument.id} />
          </div>
        </div>
      </div>
    </>
  )
}
