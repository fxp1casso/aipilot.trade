"use client"

import { useState } from "react"
import { SignalTerminalHeader } from "./signal-terminal-header"
import { CopilotChartPanel } from "./copilot-chart-panel"
import { ConfluenceBottomBar } from "./bottom-bar/confluence-bottom-bar"
import { getInstrumentById, type Instrument } from "@/lib/instruments"

export function ExecutionCopilotLayout() {
  const [activeInstrument, setActiveInstrument] = useState<Instrument>(getInstrumentById("EURUSD")!)

  return (
    <div className="flex flex-col h-screen bg-[#0D0F17] text-white">
      <header>
        <SignalTerminalHeader activeInstrument={activeInstrument} setActiveInstrument={setActiveInstrument} />
      </header>
      <main className="flex-grow flex overflow-hidden">
        <div className="flex-grow flex flex-col">
          <CopilotChartPanel instrument={activeInstrument} />
          <ConfluenceBottomBar />
        </div>
        <aside className="w-[380px] flex-shrink-0 bg-[#12141C] border-l border-gray-800 overflow-y-auto">
          {/* Right panel content can be placed directly here or as a separate component */}
        </aside>
      </main>
    </div>
  )
}
