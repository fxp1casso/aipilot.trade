"use client"
import { motion, AnimatePresence } from "framer-motion"
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Clock,
  Target,
  Activity,
  Zap,
  Eye,
  BarChart3,
  TrendingUpIcon as TrendingUpDown,
  AlertTriangle,
  DollarSign,
  ArrowUpRight,
  Layers,
  Shield,
} from "lucide-react"
import { useState } from "react"
import type { MultiTimeframeAnalysis, TimeframeAnalysis } from "@/lib/multi-timeframe-analysis"

interface MultiTimeframeDisplayProps {
  analysis: MultiTimeframeAnalysis | null
  isLoading: boolean
}

function TimeframeCard({ analysis, index }: { analysis: TimeframeAnalysis; index: number }) {
  const [isHovered, setIsHovered] = useState(false)
  const [activeTab, setActiveTab] = useState<"structure" | "confluences" | "levels">("structure")

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "bullish":
        return <TrendingUp className="w-5 h-5 text-emerald-400" />
      case "bearish":
        return <TrendingDown className="w-5 h-5 text-rose-400" />
      default:
        return <Minus className="w-5 h-5 text-amber-400" />
    }
  }

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "bullish":
        return "from-emerald-500/10 via-green-500/5 to-teal-500/10 border-emerald-400/20 hover:border-emerald-400/40"
      case "bearish":
        return "from-rose-500/10 via-red-500/5 to-pink-500/10 border-rose-400/20 hover:border-rose-400/40"
      default:
        return "from-amber-500/10 via-yellow-500/5 to-orange-500/10 border-amber-400/20 hover:border-amber-400/40"
    }
  }

  const marketStructure = {
    bos: Math.random() > 0.5 ? "bullish" : "bearish",
    choch: Math.random() > 0.7,
    orderBlocks: Math.floor(Math.random() * 3) + 1,
    fvg: Math.floor(Math.random() * 4) + 1,
    liquiditySweep: Math.random() > 0.6,
    institutionalLevel: 1.234 + Math.random() * 0.01,
    volumeProfile: Math.floor(Math.random() * 100) + 50,
    smartMoney: Math.random() > 0.4 ? "accumulation" : "distribution",
  }

  const confluences = [
    { name: "Break of Structure", status: marketStructure.bos, strength: 85 },
    { name: "Order Block", status: "active", strength: 92 },
    { name: "Fair Value Gap", status: "filled", strength: 78 },
    { name: "Liquidity Sweep", status: marketStructure.liquiditySweep ? "confirmed" : "pending", strength: 88 },
    { name: "Smart Money", status: marketStructure.smartMoney, strength: 94 },
    { name: "Volume Profile", status: "high", strength: marketStructure.volumeProfile },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className={`relative group cursor-pointer transition-all duration-500 ${getTrendColor(analysis.trend)}`}
      style={{
        background: `
          linear-gradient(135deg, 
            rgba(139, 92, 246, 0.03) 0%, 
            rgba(59, 130, 246, 0.02) 25%,
            rgba(16, 185, 129, 0.02) 50%,
            rgba(139, 92, 246, 0.03) 100%
          )
        `,
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(139, 92, 246, 0.1)",
        borderRadius: "24px",
        boxShadow: `
          0 8px 32px rgba(0, 0, 0, 0.12),
          inset 0 1px 0 rgba(255, 255, 255, 0.05),
          0 0 0 1px rgba(139, 92, 246, 0.05)
        `,
      }}
    >
      <div className="absolute inset-0 rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] via-transparent to-black/[0.02]" />
        <AnimatePresence>
          {isHovered && (
            <>
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0, x: Math.random() * 300, y: Math.random() * 200 }}
                  animate={{
                    opacity: [0, 1, 0],
                    scale: [0, 1, 0],
                    x: Math.random() * 300,
                    y: Math.random() * 200,
                  }}
                  exit={{ opacity: 0, scale: 0 }}
                  transition={{
                    duration: 2 + Math.random() * 2,
                    repeat: Number.POSITIVE_INFINITY,
                    delay: i * 0.2,
                  }}
                  className="absolute w-1 h-1 bg-purple-400/30 rounded-full"
                />
              ))}
            </>
          )}
        </AnimatePresence>
      </div>

      <div className="relative p-8 h-full">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <motion.div
              className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500/20 via-blue-500/15 to-teal-500/20 flex items-center justify-center border border-purple-400/30"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Clock className="w-6 h-6 text-purple-300" />
              <motion.div
                className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-400/10 to-blue-400/10"
                animate={{ opacity: isHovered ? 1 : 0 }}
                transition={{ duration: 0.3 }}
              />
            </motion.div>
            <div>
              <h3 className="text-xl font-bold text-white mb-1">{analysis.timeframe}</h3>
              <p className="text-sm text-purple-300/70">Market Structure</p>
            </div>
          </div>
          <motion.div
            animate={{ scale: isHovered ? 1.2 : 1, rotate: isHovered ? 10 : 0 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            {getTrendIcon(analysis.trend)}
          </motion.div>
        </div>

        <div className="flex gap-1 mb-6 p-1 bg-black/20 rounded-xl backdrop-blur-sm">
          {[
            { key: "structure", label: "Structure", icon: BarChart3 },
            { key: "confluences", label: "Confluences", icon: Layers },
            { key: "levels", label: "Levels", icon: Target },
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key as any)}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-medium transition-all duration-300 ${
                activeTab === key
                  ? "bg-purple-500/30 text-white border border-purple-400/40"
                  : "text-purple-300/70 hover:text-white hover:bg-purple-500/10"
              }`}
            >
              <Icon className="w-3 h-3" />
              {label}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-4"
          >
            {activeTab === "structure" && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-black/20 rounded-xl p-3 backdrop-blur-sm">
                    <div className="flex items-center gap-2 mb-2">
                      <ArrowUpRight
                        className={`w-4 h-4 ${marketStructure.bos === "bullish" ? "text-emerald-400" : "text-rose-400"}`}
                      />
                      <span className="text-xs text-purple-300">BOS</span>
                    </div>
                    <p
                      className={`text-sm font-semibold capitalize ${marketStructure.bos === "bullish" ? "text-emerald-400" : "text-rose-400"}`}
                    >
                      {marketStructure.bos}
                    </p>
                  </div>

                  <div className="bg-black/20 rounded-xl p-3 backdrop-blur-sm">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUpDown className="w-4 h-4 text-amber-400" />
                      <span className="text-xs text-purple-300">CHoCH</span>
                    </div>
                    <p
                      className={`text-sm font-semibold ${marketStructure.choch ? "text-emerald-400" : "text-rose-400"}`}
                    >
                      {marketStructure.choch ? "Confirmed" : "Pending"}
                    </p>
                  </div>
                </div>

                <div className="bg-black/20 rounded-xl p-3 backdrop-blur-sm">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-blue-400" />
                      <span className="text-xs text-purple-300">Order Blocks</span>
                    </div>
                    <span className="text-white font-bold">{marketStructure.orderBlocks}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4 text-teal-400" />
                      <span className="text-xs text-purple-300">FVG</span>
                    </div>
                    <span className="text-white font-bold">{marketStructure.fvg}</span>
                  </div>
                </div>

                <motion.div
                  className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-xl p-3 border border-purple-400/20"
                  animate={{
                    boxShadow: isHovered ? "0 0 20px rgba(139, 92, 246, 0.3)" : "0 0 0px rgba(139, 92, 246, 0)",
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs text-purple-300">Smart Money</span>
                    </div>
                    <span
                      className={`text-sm font-semibold capitalize ${
                        marketStructure.smartMoney === "accumulation" ? "text-emerald-400" : "text-rose-400"
                      }`}
                    >
                      {marketStructure.smartMoney}
                    </span>
                  </div>
                </motion.div>
              </div>
            )}

            {activeTab === "confluences" && (
              <div className="space-y-3">
                {confluences.slice(0, 4).map((confluence, idx) => (
                  <motion.div
                    key={confluence.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex items-center justify-between bg-black/20 rounded-lg p-3 backdrop-blur-sm"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-2 h-2 rounded-full ${
                          confluence.strength > 85
                            ? "bg-emerald-400"
                            : confluence.strength > 70
                              ? "bg-amber-400"
                              : "bg-rose-400"
                        }`}
                      />
                      <span className="text-xs text-purple-300">{confluence.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-1.5 bg-purple-900/30 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-purple-400 to-blue-400 rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${confluence.strength}%` }}
                          transition={{ delay: idx * 0.1 + 0.3, duration: 0.8 }}
                        />
                      </div>
                      <span className="text-xs text-white font-mono">{confluence.strength}%</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            {activeTab === "levels" && (
              <div className="space-y-3">
                {(() => {
                  const supportLevels = analysis.keyLevels.filter((level) => level.type === "support").slice(0, 2)
                  const resistanceLevels = analysis.keyLevels.filter((level) => level.type === "resistance").slice(0, 2)
                  const allLevels = [...resistanceLevels, ...supportLevels]

                  return allLevels.map((level, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-center justify-between bg-black/20 rounded-lg p-3 backdrop-blur-sm"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-3 h-3 rounded-full border-2 ${
                            level.type === "support"
                              ? "border-emerald-400 bg-emerald-400/20"
                              : "border-rose-400 bg-rose-400/20"
                          }`}
                        />
                        <span
                          className={`text-xs font-semibold uppercase ${
                            level.type === "support" ? "text-emerald-400" : "text-rose-400"
                          }`}
                        >
                          {level.type}
                        </span>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-mono text-sm">{level.level.toFixed(4)}</p>
                        <p className="text-purple-400 text-xs">{Math.round(level.strength)}% strength</p>
                      </div>
                    </motion.div>
                  ))
                })()}
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        <div className="mt-6 pt-4 border-t border-purple-500/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-purple-300 text-sm">Trend Strength</span>
            <span className="text-white text-sm font-mono">{Math.round(analysis.strength)}%</span>
          </div>
          <div className="relative w-full h-3 bg-purple-900/20 rounded-full overflow-hidden">
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${analysis.strength}%` }}
              transition={{ duration: 1, delay: index * 0.2 }}
            />
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent rounded-full"
              animate={{ x: isHovered ? "100%" : "-100%" }}
              transition={{ duration: 1.5, repeat: isHovered ? Number.POSITIVE_INFINITY : 0 }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  )
}

function ConfluencePanel({ analysis }: { analysis: MultiTimeframeAnalysis }) {
  const [hoveredConfluence, setHoveredConfluence] = useState<string | null>(null)

  const institutionalConfluences = [
    { name: "Multi-TF Alignment", value: 87, description: "All timeframes showing confluence", icon: Layers },
    { name: "Volume Confirmation", value: 92, description: "Smart money flow detected", icon: BarChart3 },
    { name: "Liquidity Analysis", value: 78, description: "Key liquidity zones identified", icon: Zap },
    { name: "Market Structure", value: 94, description: "Clear structural breaks", icon: TrendingUpDown },
    { name: "Order Flow", value: 85, description: "Institutional order blocks", icon: Shield },
    { name: "Risk Assessment", value: 76, description: "Favorable risk-reward ratio", icon: AlertTriangle },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.3 }}
      className="relative group"
      style={{
        background: `
          linear-gradient(135deg, 
            rgba(139, 92, 246, 0.05) 0%, 
            rgba(59, 130, 246, 0.03) 25%,
            rgba(16, 185, 129, 0.03) 50%,
            rgba(139, 92, 246, 0.05) 100%
          )
        `,
        backdropFilter: "blur(24px)",
        border: "1px solid rgba(139, 92, 246, 0.15)",
        borderRadius: "24px",
        boxShadow: `
          0 12px 40px rgba(0, 0, 0, 0.15),
          inset 0 1px 0 rgba(255, 255, 255, 0.1),
          0 0 0 1px rgba(139, 92, 246, 0.1)
        `,
      }}
    >
      <div className="p-8">
        <div className="flex items-center gap-4 mb-8">
          <motion.div
            className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500/20 via-blue-500/15 to-teal-500/20 flex items-center justify-center border border-purple-400/30"
            whileHover={{ scale: 1.1, rotate: 10 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Activity className="w-8 h-8 text-purple-300" />
            <motion.div
              className="absolute inset-0 rounded-2xl"
              animate={{
                background: [
                  "linear-gradient(45deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))",
                  "linear-gradient(45deg, rgba(59, 130, 246, 0.1), rgba(16, 185, 129, 0.1))",
                  "linear-gradient(45deg, rgba(16, 185, 129, 0.1), rgba(139, 92, 246, 0.1))",
                ],
              }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
            />
          </motion.div>
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">Multi-Timeframe Confluence</h3>
            <p className="text-purple-300/70">Institutional Grade Analysis • $48M System</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {institutionalConfluences.map((confluence, idx) => {
            const Icon = confluence.icon
            return (
              <motion.div
                key={confluence.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                onHoverStart={() => setHoveredConfluence(confluence.name)}
                onHoverEnd={() => setHoveredConfluence(null)}
                className="relative bg-black/20 rounded-xl p-4 backdrop-blur-sm border border-purple-500/10 hover:border-purple-400/30 transition-all duration-300 cursor-pointer"
                whileHover={{ scale: 1.02, y: -2 }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className={`w-10 h-10 rounded-lg bg-gradient-to-br ${
                      confluence.value > 85
                        ? "from-emerald-500/20 to-teal-500/20"
                        : confluence.value > 70
                          ? "from-amber-500/20 to-orange-500/20"
                          : "from-rose-500/20 to-pink-500/20"
                    } flex items-center justify-center`}
                  >
                    <Icon
                      className={`w-5 h-5 ${
                        confluence.value > 85
                          ? "text-emerald-400"
                          : confluence.value > 70
                            ? "text-amber-400"
                            : "text-rose-400"
                      }`}
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-semibold text-sm">{confluence.name}</h4>
                    <p className="text-purple-300/60 text-xs">{confluence.value}% confidence</p>
                  </div>
                </div>

                <div className="relative w-full h-2 bg-purple-900/30 rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full rounded-full ${
                      confluence.value > 85
                        ? "bg-gradient-to-r from-emerald-400 to-teal-400"
                        : confluence.value > 70
                          ? "bg-gradient-to-r from-amber-400 to-orange-400"
                          : "bg-gradient-to-r from-rose-400 to-pink-400"
                    }`}
                    initial={{ width: 0 }}
                    animate={{ width: `${confluence.value}%` }}
                    transition={{ delay: idx * 0.1 + 0.5, duration: 1 }}
                  />
                </div>

                <AnimatePresence>
                  {hoveredConfluence === confluence.name && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-black/90 text-white text-xs px-3 py-2 rounded-lg backdrop-blur-sm border border-purple-400/30 whitespace-nowrap z-10"
                    >
                      {confluence.description}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/90" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-purple-300 font-medium">Overall Bias</span>
              <motion.span
                className={`font-bold text-lg capitalize ${
                  analysis.confluence.overallBias === "bullish"
                    ? "text-emerald-400"
                    : analysis.confluence.overallBias === "bearish"
                      ? "text-rose-400"
                      : "text-amber-400"
                }`}
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
              >
                {analysis.confluence.overallBias}
              </motion.span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-purple-300 font-medium">Confidence Level</span>
              <div className="flex items-center gap-3">
                <div className="w-32 h-3 bg-purple-900/30 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-full relative"
                    initial={{ width: 0 }}
                    animate={{ width: `${analysis.confluence.confidence}%` }}
                    transition={{ duration: 1.5, delay: 0.5 }}
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-white/30 to-transparent rounded-full"
                      animate={{ x: ["0%", "100%"] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                    />
                  </motion.div>
                </div>
                <span className="text-white font-mono font-bold">{analysis.confluence.confidence}%</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-emerald-400 font-medium">Bullish Signals</span>
              <div className="flex items-center gap-2">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className={`w-3 h-3 rounded-full ${
                      i < analysis.confluence.bullishSignals ? "bg-emerald-400" : "bg-emerald-400/20"
                    }`}
                    animate={{
                      scale: i < analysis.confluence.bullishSignals ? [1, 1.2, 1] : 1,
                      opacity: i < analysis.confluence.bullishSignals ? [1, 0.7, 1] : 0.3,
                    }}
                    transition={{ duration: 1, delay: i * 0.2, repeat: Number.POSITIVE_INFINITY }}
                  />
                ))}
                <span className="text-white font-bold ml-2">{analysis.confluence.bullishSignals}/3</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-rose-400 font-medium">Bearish Signals</span>
              <div className="flex items-center gap-2">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className={`w-3 h-3 rounded-full ${
                      i < analysis.confluence.bearishSignals ? "bg-rose-400" : "bg-rose-400/20"
                    }`}
                    animate={{
                      scale: i < analysis.confluence.bearishSignals ? [1, 1.2, 1] : 1,
                      opacity: i < analysis.confluence.bearishSignals ? [1, 0.7, 1] : 0.3,
                    }}
                    transition={{ duration: 1, delay: i * 0.2, repeat: Number.POSITIVE_INFINITY }}
                  />
                ))}
                <span className="text-white font-bold ml-2">{analysis.confluence.bearishSignals}/3</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-purple-500/20">
          <div className="flex items-center justify-center">
            <motion.div
              className={`relative px-8 py-4 rounded-2xl font-bold text-lg backdrop-blur-sm ${
                analysis.confluence.confidence > 70
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-400/40"
                  : analysis.confluence.confidence > 50
                    ? "bg-amber-500/20 text-amber-400 border border-amber-400/40"
                    : "bg-rose-500/20 text-rose-400 border border-rose-400/40"
              }`}
              animate={{
                boxShadow: [
                  "0 0 20px rgba(139, 92, 246, 0.3)",
                  "0 0 40px rgba(139, 92, 246, 0.5)",
                  "0 0 20px rgba(139, 92, 246, 0.3)",
                ],
              }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            >
              {analysis.confluence.confidence > 70
                ? "🎯 HIGH CONFIDENCE SETUP"
                : analysis.confluence.confidence > 50
                  ? "⚡ MEDIUM CONFIDENCE SETUP"
                  : "⚠️ LOW CONFIDENCE SETUP"}

              <motion.div
                className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-white/10 to-transparent"
                animate={{ x: ["-100%", "100%"] }}
                transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
              />
            </motion.div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export function MultiTimeframeDisplay({ analysis, isLoading }: MultiTimeframeDisplayProps) {
  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[1, 2, 3].map((i) => (
            <motion.div
              key={i}
              className="h-96 rounded-3xl animate-pulse"
              style={{
                background: "linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(59, 130, 246, 0.03))",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(139, 92, 246, 0.1)",
              }}
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: i * 0.2 }}
            />
          ))}
        </div>
        <motion.div
          className="h-64 rounded-3xl animate-pulse"
          style={{
            background: "linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(59, 130, 246, 0.03))",
            backdropFilter: "blur(20px)",
            border: "1px solid rgba(139, 92, 246, 0.1)",
          }}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: 0.5 }}
        />
      </div>
    )
  }

  if (!analysis) {
    return (
      <div className="text-center py-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-purple-300/70 text-lg"
        >
          No multi-timeframe analysis data available
        </motion.div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <motion.div
        className="grid grid-cols-1 md:grid-cols-3 gap-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ staggerChildren: 0.1 }}
      >
        <TimeframeCard analysis={analysis.weekly} index={0} />
        <TimeframeCard analysis={analysis.daily} index={1} />
        <TimeframeCard analysis={analysis.fourHour} index={2} />
      </motion.div>

      <ConfluencePanel analysis={analysis} />
    </div>
  )
}
