"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, TrendingUp, Clock, Globe, Target, Brain, History, Download, Maximize2, Droplets, Save } from "lucide-react"
import type { Instrument } from "@/lib/instruments"
import { multiTimeframeAnalysisEngine, type MultiTimeframeAnalysis } from "@/lib/multi-timeframe-analysis"
import { sessionAnalysisEngine, type SessionAnalysis } from "@/lib/session-analysis"
import { liquidityAnalysisEngine, type LiquidityAnalysis } from "@/lib/liquidity-analysis"
import { macroAnalysisEngine, type MacroAnalysis } from "@/lib/macro-analysis"
import { MultiTimeframeDisplay } from "@/components/multi-timeframe-display"
import { SessionAnalysisDisplay } from "@/components/session-analysis-display"
import { LiquidityAnalysisDisplay } from "@/components/liquidity-analysis-display"
import { MacroAnalysisDisplay } from "@/components/macro-analysis-display"
import { StrategicReviewTab } from "@/components/strategic-review-tab"
import { analysisHistoryManager } from "@/lib/analysis-history"

interface PremiumChartAnalysisModalProps {
  isOpen: boolean
  onClose: () => void
  activeInstrument: Instrument
}

export function PremiumChartAnalysisModal({ isOpen, onClose, activeInstrument }: PremiumChartAnalysisModalProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [analysis, setAnalysis] = useState<MultiTimeframeAnalysis | null>(null)
  const [sessionAnalysis, setSessionAnalysis] = useState<SessionAnalysis | null>(null)
  const [liquidityAnalysis, setLiquidityAnalysis] = useState<LiquidityAnalysis | null>(null)
  const [macroAnalysis, setMacroAnalysis] = useState<MacroAnalysis | null>(null)
  // Added state for save functionality
  const [isSaving, setIsSaving] = useState(false)
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [saveForm, setSaveForm] = useState({ name: "", description: "", tags: "" })

  useEffect(() => {
    if (isOpen) {
      setIsLoading(true)
      setAnalysis(null)
      setSessionAnalysis(null)
      setLiquidityAnalysis(null)
      setMacroAnalysis(null)

      Promise.all([
        multiTimeframeAnalysisEngine.analyzeMultiTimeframe(activeInstrument.symbol),
        sessionAnalysisEngine.analyzeSessionData(activeInstrument.symbol),
        liquidityAnalysisEngine.analyzeLiquidity(activeInstrument.symbol),
        macroAnalysisEngine.analyzeMacroeconomics(activeInstrument.symbol),
      ])
        .then(([mtfResult, sessionResult, liquidityResult, macroResult]) => {
          setAnalysis(mtfResult)
          setSessionAnalysis(sessionResult)
          setLiquidityAnalysis(liquidityResult)
          setMacroAnalysis(macroResult)
          setIsLoading(false)

          // Auto-populate save form
          setSaveForm({
            name: `${activeInstrument.symbol} Analysis - ${new Date().toLocaleDateString()}`,
            description: `Comprehensive analysis including ${mtfResult.confluence.overallBias} bias with ${mtfResult.confluence.confidence}% confidence`,
            tags: `${activeInstrument.symbol}, ${mtfResult.confluence.overallBias}, analysis`,
          })
        })
        .catch((error) => {
          console.error("Analysis failed:", error)
          setIsLoading(false)
        })
    }
  }, [isOpen, activeInstrument])

  // Added save functionality
  const handleSaveAnalysis = async () => {
    if (!analysis || !sessionAnalysis || !liquidityAnalysis || !macroAnalysis) return

    setIsSaving(true)
    try {
      const tags = saveForm.tags
        .split(",")
        .map((tag) => tag.trim())
        .filter(Boolean)

      await analysisHistoryManager.saveAnalysis(
        activeInstrument.symbol,
        saveForm.name,
        saveForm.description,
        analysis,
        sessionAnalysis,
        liquidityAnalysis,
        macroAnalysis,
        tags,
      )

      setShowSaveDialog(false)
      // Show success feedback
    } catch (error) {
      console.error("Failed to save analysis:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const tabs = [
    { id: "overview", label: "Multi-Timeframe", icon: TrendingUp },
    { id: "sessions", label: "Sessions", icon: Clock },
    { id: "liquidity", label: "Liquidity", icon: Droplets },
    { id: "macro", label: "Macro", icon: Globe },
    { id: "levels", label: "Levels", icon: Target },
    { id: "structure", label: "Structure", icon: Brain },
    { id: "history", label: "History", icon: History },
  ]

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
          style={{ backgroundColor: "rgba(0, 0, 0, 0.8)" }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="w-full max-w-7xl h-[90vh] relative flex flex-col"
          >
            {/* Premium Glass Container */}
            <div className="h-full rounded-3xl bg-gradient-to-br from-black/40 via-purple-900/20 to-blue-900/20 backdrop-blur-3xl border border-purple-500/30 shadow-2xl overflow-hidden flex flex-col">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-purple-500/20 flex-shrink-0">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/30 to-blue-500/30 flex items-center justify-center border border-purple-500/40">
                    <TrendingUp className="w-6 h-6 text-purple-300" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                      Premium Chart Analysis
                    </h2>
                    <p className="text-purple-300/80 text-sm">
                      {activeInstrument.symbol} • Institutional Grade Analysis
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Updated save button to show save dialog */}
                  <button
                    onClick={() => setShowSaveDialog(true)}
                    className="premium-glass-icon-button"
                    disabled={isLoading}
                  >
                    <Save className="w-4 h-4" />
                  </button>
                  <button className="premium-glass-icon-button">
                    <Download className="w-4 h-4" />
                  </button>
                  <button className="premium-glass-icon-button">
                    <Maximize2 className="w-4 h-4" />
                  </button>
                  <button onClick={onClose} className="premium-glass-icon-button hover:bg-red-500/20">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Tab Navigation */}
              <div className="flex items-center gap-1 p-4 border-b border-purple-500/10 flex-shrink-0">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                      activeTab === tab.id
                        ? "bg-gradient-to-r from-purple-500/30 to-blue-500/30 text-white border border-purple-500/40"
                        : "text-purple-300/70 hover:text-white hover:bg-purple-500/10"
                    }`}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span className="text-sm font-medium">{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Content Area */}
              <div className="flex-1 p-6 overflow-y-auto min-h-0">
                <div className="space-y-6">
                  {activeTab === "overview" && <MultiTimeframeDisplay analysis={analysis} isLoading={isLoading} />}

                  {activeTab === "sessions" && (
                    <SessionAnalysisDisplay analysis={sessionAnalysis} isLoading={isLoading} />
                  )}

                  {activeTab === "liquidity" && (
                    <LiquidityAnalysisDisplay analysis={liquidityAnalysis} isLoading={isLoading} />
                  )}

                  {activeTab === "macro" && <MacroAnalysisDisplay analysis={macroAnalysis} isLoading={isLoading} />}

                  {activeTab === "structure" && (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                      <StrategicReviewTab
                        forecast={{
                          id: "premium-analysis",
                          symbol: activeInstrument.symbol,
                          direction: analysis?.confluence.overallBias || "neutral",
                          confidence: analysis?.confluence.confidence || 50,
                          timeframe: "Multi-TF",
                          createdAt: new Date(),
                          analysisData: {
                            confluences: analysis?.weekly.keyLevels.map((l) => l.type) || [],
                            psychology: {
                              focus: 85,
                              discipline: 90,
                              biases: ["Confirmation Bias", "Anchoring"],
                            },
                            executionDetails: {
                              entry: "Market Order",
                              stopLoss: "2% below entry",
                              takeProfit: "Multiple targets",
                              riskReward: "1:3",
                              timeframe: "4H-Daily",
                              duration: "3-5 days",
                              session: "London/NY Overlap",
                            },
                            aiStrategicRationale: "High-probability setup with multiple confluences",
                          },
                        }}
                      />
                    </motion.div>
                  )}

                  {activeTab === "levels" && (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                      <div className="text-center py-12">
                        <motion.div
                          className="relative p-8 rounded-3xl"
                          style={{
                            background: `
                              linear-gradient(135deg, 
                                rgba(139, 92, 246, 0.08) 0%, 
                                rgba(59, 130, 246, 0.05) 50%,
                                rgba(139, 92, 246, 0.08) 100%
                              )
                            `,
                            backdropFilter: "blur(24px)",
                            border: "1px solid rgba(139, 92, 246, 0.2)",
                          }}
                          animate={{
                            boxShadow: [
                              "0 0 20px rgba(139, 92, 246, 0.3)",
                              "0 0 40px rgba(139, 92, 246, 0.5)",
                              "0 0 20px rgba(139, 92, 246, 0.3)",
                            ],
                          }}
                          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                        >
                          <Target className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                          <h3 className="text-2xl font-bold text-white mb-2">Advanced Levels Analysis</h3>
                          <p className="text-purple-300 text-lg">$48M Premium System • Coming Soon</p>
                        </motion.div>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === "history" && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center py-12"
                    >
                      <div
                        className="relative p-8 rounded-3xl"
                        style={{
                          background: `
                            linear-gradient(135deg, 
                              rgba(139, 92, 246, 0.08) 0%, 
                              rgba(59, 130, 246, 0.05) 50%,
                              rgba(139, 92, 246, 0.08) 100%
                            )
                          `,
                          backdropFilter: "blur(24px)",
                          border: "1px solid rgba(139, 92, 246, 0.2)",
                        }}
                      >
                        <History className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                        <h3 className="text-2xl font-bold text-white mb-2">Analysis History</h3>
                        <p className="text-purple-300 text-lg">Premium tracking and insights</p>
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Added save dialog */}
          {showSaveDialog && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50 flex items-center justify-center z-10"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-gradient-to-br from-black/60 via-purple-900/30 to-blue-900/30 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-6 w-full max-w-md"
              >
                <h3 className="text-xl font-bold text-white mb-4">Save Analysis</h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-purple-300 mb-2">Name</label>
                    <input
                      type="text"
                      value={saveForm.name}
                      onChange={(e) => setSaveForm({ ...saveForm, name: e.target.value })}
                      className="w-full p-3 bg-black/30 border border-purple-500/30 rounded-lg text-white placeholder-purple-400 focus:outline-none focus:border-purple-500/50"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-purple-300 mb-2">Description</label>
                    <textarea
                      value={saveForm.description}
                      onChange={(e) => setSaveForm({ ...saveForm, description: e.target.value })}
                      rows={3}
                      className="w-full p-3 bg-black/30 border border-purple-500/30 rounded-lg text-white placeholder-purple-400 focus:outline-none focus:border-purple-500/50 resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-purple-300 mb-2">Tags (comma separated)</label>
                    <input
                      type="text"
                      value={saveForm.tags}
                      onChange={(e) => setSaveForm({ ...saveForm, tags: e.target.value })}
                      placeholder="e.g., EUR/USD, bullish, high-confidence"
                      className="w-full p-3 bg-black/30 border border-purple-500/30 rounded-lg text-white placeholder-purple-400 focus:outline-none focus:border-purple-500/50"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-6">
                  <button
                    onClick={handleSaveAnalysis}
                    disabled={isSaving || !saveForm.name.trim()}
                    className="flex-1 premium-glass-action-button disabled:opacity-50"
                  >
                    {isSaving ? "Saving..." : "Save Analysis"}
                  </button>
                  <button
                    onClick={() => setShowSaveDialog(false)}
                    className="px-4 py-2 text-purple-300 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
