"use client"

import { useState, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Trophy,
  Medal,
  TrendingUp,
  Target,
  Eye,
  ThumbsUp,
  Crown,
  Award,
  Users,
  Filter,
  Star,
  Flame,
  Activity,
} from "lucide-react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface LeaderboardEntry {
  id: string
  rank: number
  user: {
    name: string
    username: string
    avatar: string
    role: "mentor" | "student"
    badges: string[]
    verified: boolean
  }
  stats: {
    totalForecasts: number
    accuracy: number
    winRate: number
    currentStreak: number
    totalPoints: number
    avgRiskReward: number
    bestAccuracy: number
    longestStreak: number
    totalComments: number
    totalLikes: number
    totalViews: number
  }
  specialization: string[]
  tier: {
    name: string
    color: string
    gradient: string
  }
  communityId?: string
  joinedDate: string
  lastActive: string
}

type LeaderboardTab = "global" | "communities" | "mentors" | "personal"
type SortBy = "points" | "accuracy" | "winRate" | "forecasts" | "streak"
type TimePeriod = "today" | "week" | "month" | "allTime"
type AssetClass = "all" | "forex" | "crypto" | "stocks" | "indices"

const mockLeaderboardData: LeaderboardEntry[] = [
  {
    id: "1",
    rank: 1,
    user: {
      name: "Alexandra Chen",
      username: "@alextrader",
      avatar: "/professional-trader.png",
      role: "mentor",
      badges: ["Expert", "Verified", "Top Performer"],
      verified: true,
    },
    stats: {
      totalForecasts: 247,
      accuracy: 94.2,
      winRate: 87.3,
      currentStreak: 23,
      totalPoints: 15840,
      avgRiskReward: 2.4,
      bestAccuracy: 98.5,
      longestStreak: 31,
      totalComments: 456,
      totalLikes: 1247,
      totalViews: 8934,
    },
    specialization: ["Forex", "Indices"],
    tier: {
      name: "Diamond Elite",
      color: "text-cyan-400",
      gradient: "from-cyan-400 to-blue-500",
    },
    joinedDate: "2023-01-15",
    lastActive: "2 hours ago",
  },
  {
    id: "2",
    rank: 2,
    user: {
      name: "Marcus Rodriguez",
      username: "@cryptoking",
      avatar: "/forex-expert.png",
      role: "mentor",
      badges: ["Expert", "Crypto Specialist"],
      verified: true,
    },
    stats: {
      totalForecasts: 189,
      accuracy: 91.8,
      winRate: 84.2,
      currentStreak: 18,
      totalPoints: 14650,
      avgRiskReward: 2.1,
      bestAccuracy: 96.2,
      longestStreak: 28,
      totalComments: 321,
      totalLikes: 987,
      totalViews: 7234,
    },
    specialization: ["Crypto", "Forex"],
    tier: {
      name: "Platinum Pro",
      color: "text-purple-400",
      gradient: "from-purple-400 to-pink-500",
    },
    joinedDate: "2023-02-20",
    lastActive: "1 hour ago",
  },
  {
    id: "3",
    rank: 3,
    user: {
      name: "Sarah Kim",
      username: "@sarahstocks",
      avatar: "/student-trader.png",
      role: "student",
      badges: ["Advanced", "Rising Star"],
      verified: false,
    },
    stats: {
      totalForecasts: 156,
      accuracy: 89.4,
      winRate: 81.7,
      currentStreak: 12,
      totalPoints: 12890,
      avgRiskReward: 1.9,
      bestAccuracy: 94.8,
      longestStreak: 22,
      totalComments: 234,
      totalLikes: 756,
      totalViews: 5678,
    },
    specialization: ["Indices", "Commodities"],
    tier: {
      name: "Gold Master",
      color: "text-amber-400",
      gradient: "from-amber-400 to-orange-500",
    },
    joinedDate: "2023-03-10",
    lastActive: "30 minutes ago",
  },
  {
    id: "4",
    rank: 4,
    user: {
      name: "David Thompson",
      username: "@davidfx",
      avatar: "/forex-student.png",
      role: "student",
      badges: ["Advanced", "Consistent"],
      verified: false,
    },
    stats: {
      totalForecasts: 134,
      accuracy: 87.2,
      winRate: 79.1,
      currentStreak: 8,
      totalPoints: 11240,
      avgRiskReward: 1.7,
      bestAccuracy: 92.3,
      longestStreak: 19,
      totalComments: 189,
      totalLikes: 623,
      totalViews: 4567,
    },
    specialization: ["Forex", "Crypto"],
    tier: {
      name: "Silver Elite",
      color: "text-zinc-400",
      gradient: "from-zinc-400 to-slate-500",
    },
    joinedDate: "2023-04-05",
    lastActive: "4 hours ago",
  },
  {
    id: "5",
    rank: 5,
    user: {
      name: "Emma Wilson",
      username: "@emmacrypto",
      avatar: "/professional-trader.png",
      role: "student",
      badges: ["Intermediate", "Fast Learner"],
      verified: false,
    },
    stats: {
      totalForecasts: 98,
      accuracy: 85.7,
      winRate: 76.5,
      currentStreak: 6,
      totalPoints: 9680,
      avgRiskReward: 1.5,
      bestAccuracy: 89.6,
      longestStreak: 15,
      totalComments: 123,
      totalLikes: 445,
      totalViews: 3234,
    },
    specialization: ["Crypto", "Indices"],
    tier: {
      name: "Bronze Pro",
      color: "text-orange-600",
      gradient: "from-orange-600 to-red-500",
    },
    joinedDate: "2023-05-12",
    lastActive: "1 day ago",
  },
]

interface PremiumLeaderboardProps {
  className?: string
}

export function PremiumLeaderboard({ className }: PremiumLeaderboardProps) {
  const [activeTab, setActiveTab] = useState<LeaderboardTab>("global")
  const [sortBy, setSortBy] = useState<SortBy>("points")
  const [timePeriod, setTimePeriod] = useState<TimePeriod>("allTime")
  const [assetClass, setAssetClass] = useState<AssetClass>("all")
  const [hoveredEntry, setHoveredEntry] = useState<string | null>(null)

  const sortedData = useMemo(() => {
    return [...mockLeaderboardData].sort((a, b) => {
      switch (sortBy) {
        case "accuracy":
          return b.stats.accuracy - a.stats.accuracy
        case "winRate":
          return b.stats.winRate - a.stats.winRate
        case "forecasts":
          return b.stats.totalForecasts - a.stats.totalForecasts
        case "streak":
          return b.stats.currentStreak - a.stats.currentStreak
        default:
          return b.stats.totalPoints - a.stats.totalPoints
      }
    })
  }, [sortBy])

  const tabs = [
    { id: "global", label: "Global Rankings", icon: Trophy, description: "All public traders" },
    { id: "communities", label: "My Communities", icon: Users, description: "Your community rankings" },
    { id: "mentors", label: "Mentor Board", icon: Crown, description: "Top mentors" },
    { id: "personal", label: "Personal Stats", icon: Target, description: "Your performance" },
  ]

  const sortOptions = [
    { id: "points", label: "Points", icon: Crown },
    { id: "accuracy", label: "Accuracy", icon: Target },
    { id: "winRate", label: "Win Rate", icon: TrendingUp },
    { id: "forecasts", label: "Forecasts", icon: Activity },
    { id: "streak", label: "Streak", icon: Flame },
  ]

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-amber-400" />
      case 2:
        return <Medal className="w-6 h-6 text-zinc-400" />
      case 3:
        return <Award className="w-6 h-6 text-orange-400" />
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-800 flex items-center justify-center">
            <span className="text-sm font-bold text-zinc-300">#{rank}</span>
          </div>
        )
    }
  }

  const LeaderboardEntry = ({ entry, index }: { entry: LeaderboardEntry; index: number }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      onHoverStart={() => setHoveredEntry(entry.id)}
      onHoverEnd={() => setHoveredEntry(null)}
      className={cn(
        "premium-glass-container leaderboard-entry-hover p-6 cursor-pointer relative",
        entry.rank <= 3 && "border-2",
        entry.rank === 1 && "border-amber-400/50 bg-gradient-to-r from-amber-500/10 to-yellow-500/5",
        entry.rank === 2 && "border-zinc-400/50 bg-gradient-to-r from-zinc-400/10 to-slate-400/5",
        entry.rank === 3 && "border-orange-400/50 bg-gradient-to-r from-orange-500/10 to-red-500/5",
      )}
    >
      {/* Rank and Tier Badge */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          {getRankIcon(entry.rank)}
          <Badge className={cn("bg-gradient-to-r text-white border-0 font-bold text-xs", entry.tier.gradient)}>
            {entry.tier.name}
          </Badge>
        </div>
        {entry.user.verified && (
          <div className="flex items-center gap-1 text-blue-400">
            <Star className="w-4 h-4 fill-current" />
            <span className="text-xs">Verified</span>
          </div>
        )}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-12 gap-4 items-center">
        {/* Avatar and User Info */}
        <div className="col-span-4 flex items-center gap-4">
          <div className="relative">
            <Image
              src={entry.user.avatar || "/placeholder.svg"}
              alt={entry.user.name}
              width={50}
              height={50}
              className="rounded-full border-2 border-purple-400/50"
            />
            {entry.stats.currentStreak > 0 && (
              <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-emerald-500 to-green-400 rounded-full px-1.5 py-0.5 text-xs font-bold text-white flex items-center gap-1">
                <Flame className="w-3 h-3" />
                {entry.stats.currentStreak}
              </div>
            )}
          </div>
          <div className="space-y-1">
            <h3 className="font-bold text-white text-lg">{entry.user.name}</h3>
            <p className="text-sm text-purple-300">{entry.user.username}</p>
            <div className="flex items-center gap-2">
              <Badge
                className={cn(
                  "text-xs px-2 py-0.5",
                  entry.user.role === "mentor"
                    ? "bg-purple-500/20 text-purple-300 border-purple-400/30"
                    : "bg-blue-500/20 text-blue-300 border-blue-400/30",
                )}
              >
                {entry.user.role === "mentor" ? "Mentor" : "Student"}
              </Badge>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="col-span-5 grid grid-cols-2 gap-3 text-sm">
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-zinc-400">
              <Activity className="w-3 h-3" />
              <span>Forecasts</span>
            </div>
            <div className="font-bold text-white">{entry.stats.totalForecasts}</div>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-zinc-400">
              <Target className="w-3 h-3" />
              <span>Accuracy</span>
            </div>
            <div className="font-bold text-emerald-400">{entry.stats.accuracy}%</div>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-zinc-400">
              <TrendingUp className="w-3 h-3" />
              <span>Win Rate</span>
            </div>
            <div className="font-bold text-blue-400">{entry.stats.winRate}%</div>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-zinc-400">
              <Flame className="w-3 h-3" />
              <span>Streak</span>
            </div>
            <div className="font-bold text-orange-400">{entry.stats.currentStreak}</div>
          </div>
        </div>

        {/* Points */}
        <div className="col-span-3 text-right space-y-2">
          <div className={cn("text-3xl font-bold", entry.tier.color)}>{entry.stats.totalPoints.toLocaleString()}</div>
          <div className="text-xs text-zinc-400">points</div>
          <div className="flex items-center justify-end gap-3 text-xs text-zinc-500">
            <span className="flex items-center gap-1">
              <ThumbsUp className="w-3 h-3" />
              {entry.stats.totalLikes}
            </span>
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {entry.stats.totalViews}
            </span>
          </div>
        </div>
      </div>

      {/* Specialization Tags */}
      <div className="flex items-center gap-2 mt-4">
        {entry.specialization.map((spec) => (
          <Badge key={spec} variant="outline" className="text-xs border-zinc-600 text-zinc-300 bg-zinc-800/50">
            {spec}
          </Badge>
        ))}
      </div>

      {/* Expanded Details */}
      <AnimatePresence>
        {hoveredEntry === entry.id && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="mt-6 pt-6 border-t border-zinc-700/50"
          >
            <div className="grid grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-emerald-400">{entry.stats.avgRiskReward}:1</div>
                <div className="text-xs text-zinc-400">Avg R:R</div>
              </div>
              <div>
                <div className="text-lg font-bold text-blue-400">{entry.stats.bestAccuracy}%</div>
                <div className="text-xs text-zinc-400">Best Accuracy</div>
              </div>
              <div>
                <div className="text-lg font-bold text-amber-400">{entry.stats.longestStreak}</div>
                <div className="text-xs text-zinc-400">Longest Streak</div>
              </div>
              <div>
                <div className="text-lg font-bold text-purple-400">{entry.stats.totalComments}</div>
                <div className="text-xs text-zinc-400">Comments</div>
              </div>
            </div>
            <div className="flex items-center justify-between text-xs text-zinc-500 mt-4">
              <span>Joined: {new Date(entry.joinedDate).toLocaleDateString()}</span>
              <span>Last active: {entry.lastActive}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )

  return (
    <div className={cn("space-y-6", className)}>
      {/* Header */}
      <div className="premium-glass-container p-6">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-400/30">
              <Trophy className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Community Leaderboard</h2>
              <p className="text-zinc-400">Top performers in the $177M trading community</p>
            </div>
          </div>

          {/* Sort Options */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-zinc-400">Sort by:</span>
            {sortOptions.map((option) => {
              const Icon = option.icon
              return (
                <Button
                  key={option.id}
                  onClick={() => setSortBy(option.id as SortBy)}
                  variant={sortBy === option.id ? "default" : "outline"}
                  size="sm"
                  className={cn(
                    "transition-all duration-200",
                    sortBy === option.id
                      ? "bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg shadow-purple-500/25"
                      : "border-purple-400/50 text-purple-300 hover:bg-purple-500/10 bg-transparent",
                  )}
                >
                  <Icon className="w-3 h-3 mr-1" />
                  {option.label}
                </Button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="premium-glass-container p-2">
        <div className="grid grid-cols-4 gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <Button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as LeaderboardTab)}
                variant="ghost"
                className={cn(
                  "flex flex-col items-center gap-2 p-4 h-auto transition-all duration-200",
                  activeTab === tab.id
                    ? "bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg shadow-purple-500/25"
                    : "text-zinc-300 hover:text-white hover:bg-zinc-700/50",
                )}
              >
                <Icon className="w-5 h-5" />
                <div className="text-center">
                  <div className="font-semibold text-sm">{tab.label}</div>
                  <div className="text-xs opacity-70">{tab.description}</div>
                </div>
              </Button>
            )
          })}
        </div>
      </div>

      {/* Filters */}
      <div className="premium-glass-container p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-zinc-400" />
            <span className="text-sm text-zinc-400">Filters:</span>
          </div>

          {/* Time Period Filter */}
          <div className="flex items-center gap-1">
            <span className="text-xs text-zinc-500">Period:</span>
            <select
              value={timePeriod}
              onChange={(e) => setTimePeriod(e.target.value as TimePeriod)}
              className="bg-zinc-800/50 border border-zinc-600 rounded px-2 py-1 text-xs text-white"
            >
              <option value="today">Today</option>
              <option value="week">Week</option>
              <option value="month">Month</option>
              <option value="allTime">All Time</option>
            </select>
          </div>

          {/* Asset Class Filter */}
          <div className="flex items-center gap-1">
            <span className="text-xs text-zinc-500">Asset:</span>
            <select
              value={assetClass}
              onChange={(e) => setAssetClass(e.target.value as AssetClass)}
              className="bg-zinc-800/50 border border-zinc-600 rounded px-2 py-1 text-xs text-white"
            >
              <option value="all">All</option>
              <option value="forex">Forex</option>
              <option value="crypto">Crypto</option>
              <option value="stocks">Stocks</option>
              <option value="indices">Indices</option>
            </select>
          </div>
        </div>
      </div>

      {/* Leaderboard Content */}
      <div className="space-y-4">
        <AnimatePresence mode="wait">
          {sortedData.map((entry, index) => (
            <LeaderboardEntry key={entry.id} entry={entry} index={index} />
          ))}
        </AnimatePresence>
      </div>

      {/* Load More */}
      <div className="text-center">
        <Button
          variant="outline"
          className="border-purple-400/50 text-purple-300 hover:bg-purple-500/10 bg-transparent"
        >
          Load More Traders
        </Button>
      </div>
    </div>
  )
}
