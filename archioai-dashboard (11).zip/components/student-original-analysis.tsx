"use client"

import type React from "react"
import { BarChart3, TrendingUp, Target, Shield, DollarSign, Edit3 } from "lucide-react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Image from "next/image"
import type { StudentForecast } from "./student-forecast-system"
import { useState } from "react"

interface StudentOriginalAnalysisProps {
  forecast: StudentForecast & {
    analysisData?: {
      confluences: string[]
      psychology: {
        focus: number
        discipline: number
        biases: string[]
      }
      executionDetails: {
        entry: string
        stopLoss: string
        takeProfit: string
        riskReward: string
        timeframe: string
        duration: string
        session: string
      }
      aiStrategicRationale: string
    }
  }
  isEditMode: boolean
}

// Compact Glass Section component
const GlassSection = ({
  title,
  icon: Icon,
  children,
  delay = 0,
}: {
  title: string
  icon: React.ElementType
  children: React.ReactNode
  delay?: number
}) => {
  return (
    <motion.div
      className="group relative overflow-hidden rounded-xl border border-white/10 bg-black/30 backdrop-blur-sm hover:bg-black/40 transition-all duration-300"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
      whileHover={{ scale: 1.02, y: -2 }}
    >
      <div className="relative z-10 p-3">
        <motion.h4
          className="text-sm font-bold text-white mb-3 flex items-center gap-2"
          whileHover={{ x: 2 }}
          transition={{ duration: 0.2 }}
        >
          <motion.div whileHover={{ rotate: 180, scale: 1.1 }} transition={{ duration: 0.3 }}>
            <Icon className="w-4 h-4 text-purple-400" />
          </motion.div>
          {title}
        </motion.h4>
        {children}
      </div>
    </motion.div>
  )
}

// Performance Metrics Component
const PerformanceMetrics = () => {
  const metrics = [
    { label: "Win Rate", value: "73%", color: "emerald" },
    { label: "Avg R:R", value: "1:2.8", color: "cyan" },
    { label: "Accuracy", value: "85%", color: "purple" },
  ]

  return (
    <div className="grid grid-cols-3 gap-2">
      {metrics.map((metric, index) => (
        <motion.div
          key={metric.label}
          className="text-center p-2 bg-black/40 rounded-lg hover:bg-black/60 transition-all duration-300 cursor-pointer"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 + index * 0.1 }}
          whileHover={{ scale: 1.05, y: -2 }}
        >
          <div className={cn("text-lg font-bold", `text-${metric.color}-400`)}>{metric.value}</div>
          <div className="text-xs text-white">{metric.label}</div>
        </motion.div>
      ))}
    </div>
  )
}

// Editable Field Component
const EditableField = ({
  label,
  value,
  isEditing,
  onChange,
  type = "text",
  className = "",
}: {
  label: string
  value: string
  isEditing: boolean
  onChange: (value: string) => void
  type?: "text" | "textarea"
  className?: string
}) => {
  if (isEditing) {
    return (
      <div className="space-y-1">
        <label className="text-xs text-purple-400 font-semibold">{label}</label>
        {type === "textarea" ? (
          <Textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className={cn("bg-black/40 border-purple-400/30 text-white text-xs resize-none", className)}
            rows={3}
          />
        ) : (
          <Input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className={cn("bg-black/40 border-purple-400/30 text-white text-xs h-8", className)}
          />
        )}
      </div>
    )
  }

  return (
    <div className="space-y-1">
      <label className="text-xs text-purple-400 font-semibold">{label}</label>
      <div className={cn("text-xs text-white", className)}>{value}</div>
    </div>
  )
}

export function StudentOriginalAnalysis({ forecast, isEditMode }: StudentOriginalAnalysisProps) {
  const isLong = forecast.direction === "LONG"

  // Editable state
  const [editableData, setEditableData] = useState({
    pair: forecast.pair,
    direction: forecast.direction,
    entry: "130.50",
    stop: "130.10",
    target: "131.50",
    analysis: `${forecast.pair} ${forecast.direction} from 130.50 - Break and retest of daily resistance, targeting weekly high with 1:3 R:R ratio.`,
    entryPlan: "Pending retest of imbalance edge with LTF confirmation",
    riskManagement: "Beyond invalidation wick with 15-pip buffer",
    profitTarget: "Next major liquidity pool / 1:3 RR minimum",
  })

  const handleFieldChange = (field: string, value: string) => {
    setEditableData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="h-full flex flex-col space-y-3">
      <motion.div
        className="flex items-center gap-2 mb-2"
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <motion.div whileHover={{ rotate: 180, scale: 1.1 }} transition={{ duration: 0.3 }}>
          <BarChart3 className="w-5 h-5 text-purple-400" />
        </motion.div>
        <h3 className="text-lg font-bold text-white">Student's Original Analysis</h3>
        {isEditMode && (
          <motion.div className="ml-auto" whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Edit3 className="w-4 h-4 text-purple-400" />
          </motion.div>
        )}
      </motion.div>

      {/* Performance Metrics - Moved to top */}
      <GlassSection title="Performance Metrics" icon={Target} delay={0.05}>
        <PerformanceMetrics />
      </GlassSection>

      {/* Chart Analysis Entry */}
      <GlassSection title="Chart Analysis Entry" icon={BarChart3} delay={0.1}>
        <div className="relative">
          {/* Chart Image */}
          <motion.div
            className="relative w-full h-32 rounded-lg border border-white/10 overflow-hidden mb-3"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
          >
            <Image
              src="/images/chart-analysis-placeholder.png"
              alt="Chart Analysis"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <motion.div
              className="absolute bottom-2 left-2 text-xs text-white font-semibold bg-black/60 px-2 py-1 rounded-md backdrop-blur-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              Chart Analysis Entry
            </motion.div>
          </motion.div>

          {/* Trade Summary */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              {isEditMode ? (
                <Input
                  value={editableData.pair}
                  onChange={(e) => handleFieldChange("pair", e.target.value)}
                  className="bg-black/40 border-purple-400/30 text-white text-sm font-bold h-8 w-20"
                />
              ) : (
                <span className="text-sm font-bold text-white">{editableData.pair}</span>
              )}
              <Badge
                className={cn(
                  "text-xs px-2 py-1 font-bold",
                  isLong
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                    : "bg-red-500/20 text-red-300 border-red-500/40",
                )}
              >
                {isLong ? (
                  <TrendingUp className="w-3 h-3 mr-1 text-emerald-400" />
                ) : (
                  <TrendingUp className="w-3 h-3 mr-1 rotate-180 text-red-400" />
                )}
                <span className="text-white">{editableData.direction}</span>
              </Badge>
            </div>
          </div>

          <EditableField
            label="Analysis"
            value={editableData.analysis}
            isEditing={isEditMode}
            onChange={(value) => handleFieldChange("analysis", value)}
            type="textarea"
            className="leading-relaxed"
          />
        </div>
      </GlassSection>

      {/* Trade Levels */}
      <GlassSection title="Trade Levels" icon={Target} delay={0.2}>
        <div className="grid grid-cols-3 gap-2">
          <motion.div
            className="text-center p-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg"
            whileHover={{ scale: 1.05, y: -2 }}
            transition={{ duration: 0.2 }}
          >
            <div className="text-xs text-cyan-400 font-semibold mb-1">ENTRY</div>
            {isEditMode ? (
              <Input
                value={editableData.entry}
                onChange={(e) => handleFieldChange("entry", e.target.value)}
                className="bg-black/40 border-cyan-400/30 text-white text-sm font-bold h-6 text-center"
              />
            ) : (
              <div className="text-sm font-bold text-white">{editableData.entry}</div>
            )}
          </motion.div>
          <motion.div
            className="text-center p-2 bg-red-500/10 border border-red-500/30 rounded-lg"
            whileHover={{ scale: 1.05, y: -2 }}
            transition={{ duration: 0.2 }}
          >
            <div className="text-xs text-red-400 font-semibold mb-1">STOP</div>
            {isEditMode ? (
              <Input
                value={editableData.stop}
                onChange={(e) => handleFieldChange("stop", e.target.value)}
                className="bg-black/40 border-red-400/30 text-white text-sm font-bold h-6 text-center"
              />
            ) : (
              <div className="text-sm font-bold text-white">{editableData.stop}</div>
            )}
          </motion.div>
          <motion.div
            className="text-center p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg"
            whileHover={{ scale: 1.05, y: -2 }}
            transition={{ duration: 0.2 }}
          >
            <div className="text-xs text-emerald-400 font-semibold mb-1">TARGET</div>
            {isEditMode ? (
              <Input
                value={editableData.target}
                onChange={(e) => handleFieldChange("target", e.target.value)}
                className="bg-black/40 border-emerald-400/30 text-white text-sm font-bold h-6 text-center"
              />
            ) : (
              <div className="text-sm font-bold text-white">{editableData.target}</div>
            )}
          </motion.div>
        </div>
      </GlassSection>

      {/* Execution Review */}
      <div className="flex-1">
        <GlassSection title="Execution Review" icon={Shield} delay={0.3}>
          <div className="space-y-3">
            {/* Entry Plan */}
            <motion.div
              className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg"
              whileHover={{ scale: 1.02, x: 2 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center gap-2 mb-1">
                <Target className="w-3 h-3 text-emerald-400" />
                <span className="text-xs font-semibold text-emerald-400">Entry Plan:</span>
              </div>
              <EditableField
                label=""
                value={editableData.entryPlan}
                isEditing={isEditMode}
                onChange={(value) => handleFieldChange("entryPlan", value)}
                className="text-white"
              />
            </motion.div>

            {/* Risk Management */}
            <motion.div
              className="p-2 bg-red-500/10 border border-red-500/30 rounded-lg"
              whileHover={{ scale: 1.02, x: 2 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-3 h-3 text-red-400" />
                <span className="text-xs font-semibold text-red-400">Risk Management:</span>
              </div>
              <EditableField
                label=""
                value={editableData.riskManagement}
                isEditing={isEditMode}
                onChange={(value) => handleFieldChange("riskManagement", value)}
                className="text-white"
              />
            </motion.div>

            {/* Profit Target */}
            <motion.div
              className="p-2 bg-purple-500/10 border border-purple-500/30 rounded-lg"
              whileHover={{ scale: 1.02, x: 2 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center gap-2 mb-1">
                <DollarSign className="w-3 h-3 text-purple-400" />
                <span className="text-xs font-semibold text-purple-400">Profit Target:</span>
              </div>
              <EditableField
                label=""
                value={editableData.profitTarget}
                isEditing={isEditMode}
                onChange={(value) => handleFieldChange("profitTarget", value)}
                className="text-white"
              />
            </motion.div>

            {/* Trade Details */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex justify-between p-1 bg-black/40 rounded">
                <span className="text-zinc-400">Timeframe:</span>
                <span className="text-white font-medium">4H - Daily</span>
              </div>
              <div className="flex justify-between p-1 bg-black/40 rounded">
                <span className="text-zinc-400">Duration:</span>
                <span className="text-white font-medium">2-5 days</span>
              </div>
              <div className="flex justify-between p-1 bg-black/40 rounded">
                <span className="text-zinc-400">Session:</span>
                <span className="text-white font-medium">London/NY</span>
              </div>
              <div className="flex justify-between p-1 bg-black/40 rounded">
                <span className="text-zinc-400">R:R Ratio:</span>
                <span className="text-emerald-400 font-medium">1:3</span>
              </div>
            </div>
          </div>
        </GlassSection>
      </div>
    </div>
  )
}
