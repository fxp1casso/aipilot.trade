Title: Ultra-Premium Animations, Glass Effects, Hover System, and Technical Flow (v747)

This document explains the current implementation details (as of v747) and outlines gaps and estimates to achieve the fully “$100k terminal” spec. It covers:
- Animation system (per component)
- Glass design system (layers and visuals)
- HoverBoard interaction specifics
- State and technical flow (“backend” within the current front-end architecture)
- Gaps vs requested spec and an implementation estimate

1) Animation System Overview

A. FloatingConfluencePanel (components/floating-confluence-panel.tsx)
- Icon rail (confluence chips)
  - Idle micro-animations per confluence ID (function: iconIdleFor):
    - liquidity-sweep: scale pulsing 1 → 1.08 → 1 (duration ~2.8s, easeInOut, infinite)
    - bpr: rotate ±2° (duration ~4s)
    - fvg: opacity pulse 0.8 → 1 (duration ~2.2s)
    - ifvg: rotateY 0 → 180° (duration ~6s)
    - order-block: y wobble (duration ~3.6s)
    - breaker-block: rotate sway (duration ~5s)
    - po3: linear 0 → 360° rotate (duration ~14s)
    - bank-session: rotate ±8° (duration ~5s)
    - opens-pd: y wobble (duration ~3.2s)
  - Hover-in delay: 140ms (hoverTimeout) before showing the popup card
  - Hover button effects: whileHover scale 1.12, y offset for bottom dock; ring glow when locked

- Hover popup card (absolute overlay)
  - Entry/Exit: Spring with stiffness 300, damping 24
  - Initial { y: 12, opacity: 0, scale: 0.98 } → Animate { y: 0, opacity: 1, scale: 1 }
  - Exit reverses
  - Note: Current behavior overlays above siblings; it does NOT push others aside (layout reflow not used in v747)

B. UltraConfluenceCard (components/ultra-confluence/ultra-confluence-card.tsx)
- Container tilt parallax
  - Motion values mx/my bound to pointer; rotateX/rotateY transforms via useTransform
  - whileHover variants per confluence (e.g., htf: scale 1.02, y -8px, rotateX 2.5°)
- Icon micro-animations (iconKeyframes) per confluence (rotate, rotateY flips, y bobbing, etc.)
- Education “TopVisuals”
  - FlowingTrendArrows: multiple rows of animated arrows sliding across (6–7s loops)
  - StopHuntViz: sweeping vertical spike movement; blinking “Stop Hunt” label (2s loop)
  - SlidingPremiumDiscount: sliding half-panels with center line, slow back-and-forth (6s loop)
  - GapFormation: grid with two lines animating ±8px and center “gap” breathing (2.5s loop)
  - PO3Cycle: circular rotation (10s linear loop)
  - BankSessionTimeline: custom timeline (in its own file)
- LiveNumber demo metric pulses
  - useLiveNumber simulates price action; random delta every ~3.5s (+ jitter)
  - Adds brief “digits-flash” pulse on change
- BPR line scan
  - Animated gradient scan across bar; spring stiffness 140, damping 18 (restarts on midpoint changes)
- FVG editor rows (AnimatePresence)
  - Row add/remove with scale/opacity/y transitions; spring stiffness 160, damping 18
- “Learn More” mini-popup
  - Per-confluence popupVariants with specific axes (e.g., fvg rotateX, ifvg rotateY)
  - Spring (stiffness 240, damping 20)

C. EnhancedAIAnalysis (components/enhanced-ai-analysis.tsx)
- HoverBoard (animated glass panel)
  - initial: { opacity: 0, y: 40, scale: 0.95 } whileInView → { opacity: 1, y: 0, scale: 1 }
  - whileHover: scale 1.02
  - Pointer-based radial light: CSS var --mouse-x/--mouse-y drives a large radial-gradient light leak
- ExpandableHoverBoard
  - On hover: reveals expandedContent via AnimatePresence
  - initial/animate/exit on expanded content: opacity, height auto, y transitions (duration ~0.5s)
- SectionTitle icons
  - whileHover rotate 360° + scale 1.1 (duration ~0.6s)
- AnimatedGauge
  - SVG circle with strokeDashoffset animation controlled by motion controls
  - Value fades in after delay (premium “arrival” feel)
- Commentary toggle
  - Collapsible area (opacity + height transitions)
- Summary metric cards
  - whileHover scale 1.05, y -5px

D. FloatingConfluenceMenu (components/floating-confluence-menu.tsx)
- Modal overlay
  - Fade in/out (AnimatePresence), backdrop blur
- Panel
  - Spring entry: { opacity: 0, y: 30, scale: 0.98 } → { y: 0, scale: 1 }, stiffness 160, damping 18
  - Diagonal shine sweep: perpetual animated gradient sweep (duration ~3.5s, repeating)
  - Particles: subtle radial dot pattern masked with gradient, static
- Header icon
  - Gentle rotation cycles (duration ~6s)
- Progress bar
  - Gradient fill from purple to blue
- Action buttons
  - Subtle hover elevations; gear icon rotates on hover

2) Glass Design System (Visual Layers)

The current design is implemented with layered gradients, rings, blur, and shadows. Key layers and effects used across components:

- Base Glass Layer
  - bg-gradient-to-br using zinc tones and transparency (e.g., from-zinc-900/75 via-zinc-900/55 to-zinc-950/80)
  - backdrop-blur-xl/2xl to simulate frosted glass
- Border and Rim
  - border-white/10 primary border
  - ring-1 ring-purple-500/15 or ring-purple-500/30 for premium purple rim
- Light Leaks / Pointer Highlight
  - Radial gradient following pointer (HoverBoard, ExpandableHoverBoard):
    radial-gradient(800px circle at var(--mouse-x) var(--mouse-y), rgba(255,255,255,0.06), transparent 40%)
- Diagonal Shine Sweep
  - Animated linear-gradient shard passes across the panel (FloatingConfluenceMenu)
- Particle Texture
  - Subtle dot grid (radial pattern) masked with gradients (FloatingConfluenceMenu)
- Depth Shadows
  - shadow-black/40 on panels; larger shadow on hover; purple-tinted outer shadow on confluence dock
- Pills/Badges
  - Emphasis via translucent fills (emerald/red/amber 10–20%), border tints (30–40%)

3) HoverBoard Interaction Details

- Container entrance: Smooth ease-in (0.8s), slight y-rise, light scale-up
- Hover scaling: scale 1.02 (fast ~0.3s), consistent across boards for a premium “lift”
- Pointer light: tracks mouse to create a luminous halo under the cursor; opacity transitions in/out with group hover
- Expandable section:
  - Staggered reveal: opacity rises, height expands to content, y transitions up
  - Keeps a border-top with low-opacity white to emphasize the expanded seam
- Micro-interactions inside:
  - Gauges: delayed numeric fade, animated arc
  - Bullet lists: items slide in with short stagger

4) State and Technical Flow (“Backend” in current architecture)

Note: The current project is a client-first UI with local state and no server-side evaluation pipeline hooked to these specific animations. “Backend” here refers to state management and persistence used by the hover system and panels.

- FloatingConfluencePanel
  - Dock position and minimized state persisted with localStorage:
    - confluenceDockPos: "bottom" | "left"
    - confluenceBarMinimized: "1" | "0"
  - Pinned confluences loaded from useConfluenceStore (stores/confluence-store.ts)
    - Only valid UltraConfluenceId values are kept; fallback to first N (MAX_VISIBLE=5)
  - Hover vs locked state:
    - Hover sets hoveredId after a 140ms delay (queue avoids flicker)
    - Click toggles lockedId (keeps card open even when mouse leaves)
    - Popups are absolute overlays (do not reflow siblings in v747)
- UltraConfluenceCard
  - All live metrics are simulated (useLiveNumber) and are client-side only
  - No network requests for these UI interactions
- EnhancedAIAnalysis → FloatingConfluenceMenu
  - FloatingConfluenceMenu is a modal; it closes on ESC and outside click
  - Analysis data passed in as props; if not provided, a safe demo fallback is used
  - No external services are called in the modal
- Configuration
  - ConfluenceConfigModal exists and opens from the dock, but internal logic not described here; this doc focuses on the hover/animation system

Planned or Typical Integrations (not implemented in v747)
- Rules/Validation Engine: A server or worker that evaluates confluence rules per instrument/timeframe in real time
- Market Data: WebSocket price feeds; batched updates mapped into local state; rules engine runs on updates
- Alerts: Server-side scheduler and push (email/Slack/web push)
- Persistence: Pinned confluences and user preferences stored in a remote DB (e.g., Supabase/Neon)
- AI: If AI SDK is used for narratives/summaries, it would be wired via Next.js route handlers and streamed to the UI (not present in v747)

5) Timing, Easing, and Physics Summary

- Standard springs:
  - Popup cards: stiffness 300, damping 24
  - Panels/menus: stiffness 160–240, damping 18–26
  - BPR scan: stiffness 140, damping 18
- Easing:
  - Micro-interactions: easeInOut
  - Continuous rotations: linear
- Delays/staggers:
  - Hover delay on dock icons: 140ms
  - Gauge delay: 0.5–1s to “arrive” after panel opens
  - Expandable content: ~0.1–0.3s stagger on items

6) What’s Implemented vs The “$100k Terminal” Spec

Implemented (v747)
- Premium glass layers on core panels and modal
- Per-confluence icon micro-animations (idle)
- Rich UltraConfluenceCard with:
  - Top visuals per pattern
  - Live simulated numbers and inputs
  - Per-pattern hover variants and detail popups
- Dock with hover delay, lock-on-click, and minimization + location persistence
- HoverBoard and ExpandableHoverBoard sections with pointer-light and smooth expansion
- FloatingConfluenceMenu modal with diagonal shine, particles, and polished layout
- Accessibility basics: ESC close for the modal; ARIA roles on dialog; focus handling basic (not a full trap)

Not Yet Implemented (key items from your spec)
- Inline expansion that pushes siblings aside (layout reflow) in the dock (currently overlay)
- Typewriter text reveal for every textual element
- “Magnetic” hover buttons with cursor attraction physics
- Circular confidence animations inside the expanded confluence cards (vs gauges elsewhere)
- Animated flowchart for decision logic per confluence
- Real-time rule validation connected to a backend (green/amber/red live states)
- Skeleton loading states across all expanded views
- Smooth hover-queue management across quickly moved cursor paths (beyond current simple delay)
- Full keyboard nav and focus trap inside modals and expanded cards
- Sound design (hover/click subtle cues)
- Unified design tokens for glass (CSS variables) and a dark/light pass

7) Upgrade Plan to Hit the Full Spec

Milestone 1: Inline Expansion + Layout Orchestration (est. 24–36 hrs)
- Replace overlay popups with inline layout expansions (Framer Motion layout + AnimateSharedLayout)
- Manage sibling compression and scroll containment; handle both bottom and left dock
- Add “click outside/ESC” to collapse inline expansions (and restore layout)
- Performance pass: use transforms, limit reflows

Milestone 2: Tutorial Section + Typewriter and Flowchart (est. 32–48 hrs)
- Implement per-confluence tutorial sequences with typewriter reveal
- Build a compact animated flowchart component (Framer Motion), dynamic states from rules
- Add mini-charts (canvas/SVG) with shimmer skeletons

Milestone 3: Live Rules Engine Wiring (est. 40–80 hrs)
- Define a rules schema per confluence
- Connect to a server route/worker; run validations per instrument/timeframe
- Emit status colors (green/amber/red) and update the UI with pulse effects
- Implement alert creation (route handler + persistence)

Milestone 4: Micro-Interactions Suite (est. 16–28 hrs)
- Magnetic hover (cursor attraction) on action buttons
- Circular confidence indicators in the expanded cards (confluence-specific)
- Smooth hover queuing system for rapid cursor movements
- Subtle sound design (toggle-able)

Milestone 5: Accessibility, Theming, and Polish (est. 16–30 hrs)
- Focus traps, tab order, ARIA labels, reduced motion variant
- Centralize glass tokens (CSS variables) and theme scale
- Comprehensive performance audit (React Profiler), remove jank on low-end devices

8) Rough Budgetary Guidance

- Minimal polish extension (staying close to v747 with overlay popups): 40–80 hrs
- Full “inline expansion + tutorial + rules engine + micro-interactions + A11y”:
  - Total: ~128–222 hrs (conservative to realistic range)
  - Sample blended rate:
    - At $85/hr → ~$10.9k – $18.9k
    - At $125/hr → ~$16k – $27.8k
    - At $180/hr → ~$23k – $40k
- “$100k terminal” look-and-feel including robust real-time infra, historical analytics, and deep bespoke visuals across all confluences can credibly reach:
  - 350–600 hrs ($30k–$108k at $85–$180/hr), depending on data integration scope, AI features, and QA depth.

9) Performance and Quality Notes

- Use transforms (translate/scale/rotate) over top/left to avoid layout thrash
- Prefer AnimatePresence sparingly; coalesce transitions in parent where possible
- Cache heavy SVG filters or replace with CSS-only where feasible
- Avoid large box-shadow blur radii on many nodes simultaneously; use container shadows
- Debounce hover-to-expand; maintain short hover delay and a small leave grace period
- Consider GPU-friendly backface-visibility and will-change hints only where necessary

10) Immediate Next Steps (Recommended)

- Decide on inline vs overlay expansions for the dock
- Prioritize tutorial + flowchart vs live rules engine (or split)
- Lock down design tokens (CSS vars) for glass and purple glow system
- Choose target instruments and data providers for rule checks
- Schedule a performance/a11y pass baseline before adding more animation
