export default function SecuritySettingsPage() {
  return (
    <main>
      <h1>Security Settings</h1>
      <div />
    </main>
  )
}
