export default function AccountSettingsPage() {
  return (
    <main>
      <h1>Account Settings</h1>
      <div />
    </main>
  )
}
