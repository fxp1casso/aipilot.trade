export default function NotificationSettingsPage() {
  return (
    <main>
      <h1>Notification Settings</h1>
      <div />
    </main>
  )
}
