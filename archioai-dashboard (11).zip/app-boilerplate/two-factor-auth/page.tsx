export default function TwoFactorAuthPage() {
  return (
    <main>
      <h1>Two-Factor Auth</h1>
      <div />
    </main>
  )
}
