export default function PricingPage() {
  return (
    <main>
      <h1>Pricing</h1>
      <div />
    </main>
  )
}
