export default function Page() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Content Management</h1>
      <div className="mt-4" />
    </div>
  )
}
