export default function BlogListingPage() {
  return (
    <main>
      <h1>Blog Listing</h1>
      <div />
    </main>
  )
}
