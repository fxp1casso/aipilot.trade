export default function SupportPage() {
  return (
    <main>
      <h1>Support</h1>
      <div />
    </main>
  )
}
