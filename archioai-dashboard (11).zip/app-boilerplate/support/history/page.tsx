export default function TicketHistoryPage() {
  return (
    <main>
      <h1>Ticket History</h1>
      <div />
    </main>
  )
}
