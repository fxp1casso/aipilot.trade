export default function SubmitTicketPage() {
  return (
    <main>
      <h1>Submit Ticket</h1>
      <div />
    </main>
  )
}
