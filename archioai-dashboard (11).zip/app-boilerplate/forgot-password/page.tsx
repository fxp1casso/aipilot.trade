export default function ForgotPasswordPage() {
  return (
    <main>
      <h1>Forgot Password</h1>
      <div />
    </main>
  )
}
