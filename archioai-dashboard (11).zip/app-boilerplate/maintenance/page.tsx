export default function MaintenanceModePage() {
  return (
    <main>
      <h1>Maintenance Mode</h1>
      <div />
    </main>
  )
}
