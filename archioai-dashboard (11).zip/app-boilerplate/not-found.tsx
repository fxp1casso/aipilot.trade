export default function NotFound() {
  return (
    <div className="container py-16">
      <h1 className="text-3xl font-bold">404 — Not Found</h1>
      <div className="mt-4" />
    </div>
  )
}
