export default function LandingPage() {
  return (
    <main>
      <h1>Landing Page</h1>
      <div />
    </main>
  )
}
