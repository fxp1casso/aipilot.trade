export default function ApiStatusPage() {
  return (
    <main>
      <h1>API Status</h1>
      <div />
    </main>
  )
}
