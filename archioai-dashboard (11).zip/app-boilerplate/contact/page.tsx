export default function ContactPage() {
  return (
    <main>
      <h1>Contact</h1>
      <div />
    </main>
  )
}
