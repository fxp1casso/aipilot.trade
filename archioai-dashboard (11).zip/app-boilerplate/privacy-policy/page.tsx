export default function PrivacyPolicyPage() {
  return (
    <main>
      <h1>Privacy Policy</h1>
      <div />
    </main>
  )
}
