export default function FaqPage() {
  return (
    <main>
      <h1>FAQ</h1>
      <div />
    </main>
  )
}
