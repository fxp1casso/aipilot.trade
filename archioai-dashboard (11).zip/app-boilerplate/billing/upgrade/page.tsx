export default function UpgradePlanPage() {
  return (
    <main>
      <h1>Upgrade Plan</h1>
      <div />
    </main>
  )
}
