export default function BillingOverviewPage() {
  return (
    <main>
      <h1>Billing Overview</h1>
      <div />
    </main>
  )
}
