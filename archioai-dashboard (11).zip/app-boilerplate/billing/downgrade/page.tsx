export default function DowngradePlanPage() {
  return (
    <main>
      <h1>Downgrade Plan</h1>
      <div />
    </main>
  )
}
