export default function CancelSubscriptionPage() {
  return (
    <main>
      <h1>Cancel Subscription</h1>
      <div />
    </main>
  )
}
