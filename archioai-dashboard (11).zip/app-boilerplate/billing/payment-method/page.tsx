export default function UpdatePaymentMethodPage() {
  return (
    <main>
      <h1>Update Payment Method</h1>
      <div />
    </main>
  )
}
