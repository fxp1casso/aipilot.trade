export default function PaymentHistoryPage() {
  return (
    <main>
      <h1>Payment History</h1>
      <div />
    </main>
  )
}
