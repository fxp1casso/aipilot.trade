export default function CookiePolicyPage() {
  return (
    <main>
      <h1>Cookie Policy</h1>
      <div />
    </main>
  )
}
