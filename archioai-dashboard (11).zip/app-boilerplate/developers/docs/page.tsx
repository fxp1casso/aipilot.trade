export default function ApiDocsPage() {
  return (
    <main>
      <h1>API Docs</h1>
      <div />
    </main>
  )
}
