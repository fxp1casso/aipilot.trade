export default function ChangePasswordPage() {
  return (
    <main>
      <h1>Change Password</h1>
      <div />
    </main>
  )
}
