export default function UserProfilePage() {
  return (
    <main>
      <h1>User Profile</h1>
      <div />
    </main>
  )
}
