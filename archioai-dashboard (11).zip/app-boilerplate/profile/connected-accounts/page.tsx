export default function ManageConnectedAccountsPage() {
  return (
    <main>
      <h1>Manage Connected Accounts</h1>
      <div />
    </main>
  )
}
