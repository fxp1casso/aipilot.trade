export default function EditPersonalInfoPage() {
  return (
    <main>
      <h1>Edit Personal Info</h1>
      <div />
    </main>
  )
}
