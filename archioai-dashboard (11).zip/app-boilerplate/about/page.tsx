export default function AboutUsPage() {
  return (
    <main>
      <h1>About Us</h1>
      <div />
    </main>
  )
}
