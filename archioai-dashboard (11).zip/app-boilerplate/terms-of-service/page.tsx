export default function TermsOfServicePage() {
  return (
    <main>
      <h1>Terms of Service</h1>
      <div />
    </main>
  )
}
