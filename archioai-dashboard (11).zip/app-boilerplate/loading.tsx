export default function AppLoading() {
  return (
    <div className="container py-16">
      <div className="h-8 w-56 animate-pulse rounded bg-slate-200" />
      <div className="mt-4 h-28 w-full animate-pulse rounded bg-slate-100" />
    </div>
  )
}
