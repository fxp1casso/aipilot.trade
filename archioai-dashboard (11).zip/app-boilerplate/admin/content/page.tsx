export default function ContentManagementPage() {
  return (
    <main>
      <h1>Content Management</h1>
      <div />
    </main>
  )
}
