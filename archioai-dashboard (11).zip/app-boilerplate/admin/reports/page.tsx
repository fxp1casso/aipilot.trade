export default function ReportsAndAnalyticsPage() {
  return (
    <main>
      <h1>Reports &amp; Analytics</h1>
      <div />
    </main>
  )
}
