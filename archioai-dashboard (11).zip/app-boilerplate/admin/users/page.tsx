export default function UserManagementPage() {
  return (
    <main>
      <h1>User Management</h1>
      <div />
    </main>
  )
}
