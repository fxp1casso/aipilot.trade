export default function SubscriptionManagementPage() {
  return (
    <main>
      <h1>Subscription Management</h1>
      <div />
    </main>
  )
}
