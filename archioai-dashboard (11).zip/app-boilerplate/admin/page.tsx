export default function AdminDashboardPage() {
  return (
    <main>
      <h1>Admin Dashboard</h1>
      <div />
    </main>
  )
}
