export default function UsageReportsPage() {
  return (
    <main>
      <h1>Usage Reports</h1>
      <div />
    </main>
  )
}
