export default function DashboardOverviewPage() {
  return (
    <main>
      <h1>Dashboard Overview</h1>
      <div />
    </main>
  )
}
