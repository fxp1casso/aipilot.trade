export default function GoPilotChallengesPage() {
  return (
    <main>
      <h1>GoPilot Challenges</h1>
      <div />
    </main>
  )
}
