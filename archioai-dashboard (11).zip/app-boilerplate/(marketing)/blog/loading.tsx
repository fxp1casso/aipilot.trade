export default function BlogLoading() {
  return (
    <div className="space-y-2">
      <div className="h-8 w-48 animate-pulse rounded bg-slate-200" />
      <div className="h-24 w-full animate-pulse rounded bg-slate-100" />
    </div>
  )
}
