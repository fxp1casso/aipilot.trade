export default function RegisterPage() {
  return (
    <main>
      <h1>Register</h1>
      <div />
    </main>
  )
}
