export default function IntegrationsPage() {
  return (
    <main>
      <h1>Integrations</h1>
      <div />
    </main>
  )
}
